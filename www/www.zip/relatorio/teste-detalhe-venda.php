<html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="shortcut icon" href="/favicon.png"><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500"><title>Vendas</title><link href="main.be77eb79.css" rel="stylesheet"><style data-jss="" data-meta="MuiFormLabel">
.jss1010 {
  color: rgba(69, 90, 100, 0.54);
  padding: 0;
  font-size: 1rem;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1;
}
.jss1010.jss1011 {
  color: rgb(53, 122, 56);
}
.jss1010.jss1012 {
  color: rgba(69, 90, 100, 0.38);
}
.jss1010.jss1013 {
  color: #f44336;
}
.jss1016.jss1013 {
  color: #f44336;
}
</style><style data-jss="" data-meta="MuiInputLabel">
.jss1005 {
  transform-origin: top left;
}
.jss1006 {
  top: 0;
  left: 0;
  position: absolute;
  transform: translate(0, 24px) scale(1);
}
.jss1007 {
  transform: translate(0, 21px) scale(1);
}
.jss1008 {
  transform: translate(0, 1.5px) scale(0.75);
  transform-origin: top left;
}
.jss1009 {
  transition: transform 200ms cubic-bezier(0.0, 0, 0.2, 1) 0ms;
}
</style><style data-jss="" data-meta="MuiTypography">
.jss448 {
  margin: 0;
  display: block;
}
.jss449 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 7rem;
  font-weight: 300;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.14286em;
  margin-left: -.04em;
  letter-spacing: -.04em;
}
.jss450 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 3.5rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.30357em;
  margin-left: -.02em;
  letter-spacing: -.02em;
}
.jss451 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 2.8125rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.13333em;
  margin-left: -.02em;
}
.jss452 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 2.125rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.20588em;
}
.jss453 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1.5rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.35417em;
}
.jss454 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1.3125rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.16667em;
}
.jss455 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.5em;
}
.jss456 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.71429em;
}
.jss457 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.46429em;
}
.jss458 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 0.75rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.375em;
}
.jss459 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  text-transform: uppercase;
}
.jss460 {
  text-align: left;
}
.jss461 {
  text-align: center;
}
.jss462 {
  text-align: right;
}
.jss463 {
  text-align: justify;
}
.jss464 {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.jss465 {
  margin-bottom: 0.35em;
}
.jss466 {
  margin-bottom: 16px;
}
.jss467 {
  color: inherit;
}
.jss468 {
  color: #4caf50;
}
.jss469 {
  color: #ab47bc;
}
.jss470 {
  color: rgba(69, 90, 100, 0.87);
}
.jss471 {
  color: rgba(69, 90, 100, 0.54);
}
.jss472 {
  color: #f44336;
}
</style><style data-jss="" data-meta="MuiTouchRipple">
.jss427 {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: block;
  z-index: 0;
  position: absolute;
  overflow: hidden;
  border-radius: inherit;
  pointer-events: none;
}
.jss428 {
  top: 0;
  left: 0;
  width: 50px;
  height: 50px;
  opacity: 0;
  position: absolute;
}
.jss429 {
  opacity: 0.3;
  transform: scale(1);
  animation: mui-ripple-enter 550ms cubic-bezier(0.4, 0, 0.2, 1);
}
.jss430 {
  animation-duration: 200ms;
}
.jss431 {
  width: 100%;
  height: 100%;
  opacity: 1;
  display: block;
  border-radius: 50%;
  background-color: currentColor;
}
.jss432 {
  opacity: 0;
  animation: mui-ripple-exit 550ms cubic-bezier(0.4, 0, 0.2, 1);
}
.jss433 {
  top: 0;
  left: 0;
  position: absolute;
  animation: mui-ripple-pulsate 2500ms cubic-bezier(0.4, 0, 0.2, 1) 200ms infinite;
}
@-webkit-keyframes mui-ripple-enter {
  0% {
    opacity: 0.1;
    transform: scale(0);
  }
  100% {
    opacity: 0.3;
    transform: scale(1);
  }
}
@-webkit-keyframes mui-ripple-exit {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@-webkit-keyframes mui-ripple-pulsate {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(0.92);
  }
  100% {
    transform: scale(1);
  }
}
</style><style data-jss="" data-meta="MuiButtonBase">
.jss417 {
  color: inherit;
  cursor: pointer;
  margin: 0;
  border: 0;
  display: inline-flex;
  padding: 0;
  outline: none;
  position: relative;
  user-select: none;
  align-items: center;
  border-radius: 0;
  vertical-align: middle;
  justify-content: center;
  -moz-appearance: none;
  text-decoration: none;
  background-color: transparent;
  -webkit-appearance: none;
  -webkit-tap-highlight-color: transparent;
}
.jss417::-moz-focus-inner {
  border-style: none;
}
.jss417.jss418 {
  cursor: default;
  pointer-events: none;
}
</style><style data-jss="" data-meta="MuiIconButton">
.jss411 {
  flex: 0 0 auto;
  width: 48px;
  color: rgba(69, 90, 100, 0.54);
  height: 48px;
  padding: 0;
  overflow: visible;
  font-size: 1.5rem;
  text-align: center;
  transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  border-radius: 50%;
}
.jss411:hover {
  background-color: rgba(69, 90, 100, 0.08);
}
.jss411.jss415 {
  color: rgba(69, 90, 100, 0.26);
}
@media (hover: none) {
  .jss411:hover {
    background-color: transparent;
  }
}
.jss411:hover.jss415 {
  background-color: transparent;
}
.jss412 {
  color: inherit;
}
.jss413 {
  color: #4caf50;
}
.jss413:hover {
  background-color: rgba(76, 175, 80, 0.08);
}
@media (hover: none) {
  .jss413:hover {
    background-color: transparent;
  }
}
.jss414 {
  color: #ab47bc;
}
.jss414:hover {
  background-color: rgba(171, 71, 188, 0.08);
}
@media (hover: none) {
  .jss414:hover {
    background-color: transparent;
  }
}
.jss416 {
  width: 100%;
  display: flex;
  align-items: inherit;
  justify-content: inherit;
}
</style><style data-jss="" data-meta="MuiFormControl">
.jss1001 {
  margin: 0;
  border: 0;
  display: inline-flex;
  padding: 0;
  position: relative;
  min-width: 0;
  flex-direction: column;
}
.jss1002 {
  margin-top: 16px;
  margin-bottom: 8px;
}
.jss1003 {
  margin-top: 8px;
  margin-bottom: 4px;
}
.jss1004 {
  width: 100%;
}
</style><style data-jss="" data-meta="MuiListItem">
.jss553 {
  width: 100%;
  display: flex;
  position: relative;
  box-sizing: border-box;
  text-align: left;
  align-items: center;
  padding-top: 12px;
  padding-bottom: 12px;
  justify-content: flex-start;
  text-decoration: none;
}
.jss553.jss563 {
  background-color: rgba(69, 90, 100, 0.08);
}
.jss554 {
  position: relative;
}
.jss555 {
  background-color: rgba(69, 90, 100, 0.14);
}
.jss557 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.jss558 {
  opacity: 0.5;
}
.jss559 {
  border-bottom: 1px solid rgba(69, 90, 100, 0.12);
  background-clip: padding-box;
}
.jss560 {
  padding-left: 16px;
  padding-right: 16px;
}
@media (min-width:576px) {
  .jss560 {
    padding-left: 24px;
    padding-right: 24px;
  }
}
.jss561 {
  transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss561:hover {
  text-decoration: none;
  background-color: rgba(69, 90, 100, 0.14);
}
@media (hover: none) {
  .jss561:hover {
    background-color: transparent;
  }
}
.jss562 {
  padding-right: 32px;
}
</style><style data-jss="" data-meta="MuiTooltip">
.jss588 {
  z-index: 1500;
  opacity: 0.9;
}
.jss589 {
  color: #fff;
  padding: 4px 8px;
  font-size: 0.625rem;
  max-width: 300px;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.4em;
  border-radius: 4px;
  background-color: #455a64;
}
.jss590 {
  padding: 8px 16px;
  font-size: 0.875rem;
  line-height: 1.14286em;
}
.jss591 {
  margin: 0 24px ;
  transform-origin: right center;
}
@media (min-width:576px) {
  .jss591 {
    margin: 0 14px;
  }
}
.jss592 {
  margin: 0 24px;
  transform-origin: left center;
}
@media (min-width:576px) {
  .jss592 {
    margin: 0 14px;
  }
}
.jss593 {
  margin: 24px 0;
  transform-origin: center bottom;
}
@media (min-width:576px) {
  .jss593 {
    margin: 14px 0;
  }
}
.jss594 {
  margin: 24px 0;
  transform-origin: center top;
}
@media (min-width:576px) {
  .jss594 {
    margin: 14px 0;
  }
}
</style><style data-jss="">
@media (min-width:0px) and (max-width:575.95px) {
  .jss392 {
    display: none;
  }
}
@media (min-width:0px) {
  .jss393 {
    display: none;
  }
}
@media (max-width:575.95px) {
  .jss394 {
    display: none;
  }
}
@media (min-width:576px) and (max-width:767.95px) {
  .jss395 {
    display: none;
  }
}
@media (min-width:576px) {
  .jss396 {
    display: none;
  }
}
@media (max-width:767.95px) {
  .jss397 {
    display: none;
  }
}
@media (min-width:768px) and (max-width:991.95px) {
  .jss398 {
    display: none;
  }
}
@media (min-width:768px) {
  .jss399 {
    display: none;
  }
}
@media (max-width:991.95px) {
  .jss400 {
    display: none;
  }
}
@media (min-width:992px) and (max-width:1199.95px) {
  .jss401 {
    display: none;
  }
}
@media (min-width:992px) {
  .jss402 {
    display: none;
  }
}
@media (max-width:1199.95px) {
  .jss403 {
    display: none;
  }
}
@media (min-width:1200px) {
  .jss404 {
    display: none;
  }
}
@media (min-width:1200px) {
  .jss405 {
    display: none;
  }
}
@media (min-width:0px) {
  .jss406 {
    display: none;
  }
}
</style><style data-jss="" data-meta="MuiList">
.jss519 {
  margin: 0;
  padding: 0;
  position: relative;
  list-style: none;
}
.jss520 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.jss521 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.jss522 {
  padding-top: 0;
}
</style><style data-jss="" data-meta="MuiListItemText">
.jss565 {
  flex: 1 1 auto;
  padding: 0 16px;
  min-width: 0;
}
.jss565:first-child {
  padding-left: 0;
}
.jss566:first-child {
  padding-left: 56px;
}
.jss567 {
  font-size: 0.8125rem;
}
.jss568.jss570 {
  font-size: inherit;
}
.jss569.jss570 {
  font-size: inherit;
}
</style><style data-jss="" data-meta="MuiBackdrop">
.jss654 {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: -1;
  position: fixed;
  touch-action: none;
  background-color: rgba(0, 0, 0, 0.5);
  -webkit-tap-highlight-color: transparent;
}
.jss655 {
  background-color: transparent;
}
</style><style data-jss="" data-meta="MuiModal">
.jss479 {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1300;
  position: fixed;
}
.jss480 {
  visibility: hidden;
}
</style><style data-jss="" data-meta="MuiPaper">
.jss365 {
  background-color: #fff;
}
.jss366 {
  border-radius: 4px;
}
.jss367 {
  box-shadow: none;
}
.jss368 {
  box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.1),0px 1px 1px 0px rgba(0, 0, 0, 0.01),0px 2px 1px -1px rgba(0, 0, 0, 0.01);
}
.jss369 {
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.1),0px 2px 2px 0px rgba(0, 0, 0, 0.01),0px 3px 1px -2px rgba(0, 0, 0, 0.01);
}
.jss370 {
  box-shadow: 0px 1px 8px 0px rgba(0, 0, 0, 0.1),0px 3px 4px 0px rgba(0, 0, 0, 0.01),0px 3px 3px -2px rgba(0, 0, 0, 0.01);
}
.jss371 {
  box-shadow: 0px 2px 4px -1px rgba(0, 0, 0, 0.1),0px 4px 5px 0px rgba(0, 0, 0, 0.01),0px 1px 10px 0px rgba(0, 0, 0, 0.01);
}
.jss372 {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 5px 8px 0px rgba(0, 0, 0, 0.01),0px 1px 14px 0px rgba(0, 0, 0, 0.01);
}
.jss373 {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 6px 10px 0px rgba(0, 0, 0, 0.01),0px 1px 18px 0px rgba(0, 0, 0, 0.01);
}
.jss374 {
  box-shadow: 0px 4px 5px -2px rgba(0, 0, 0, 0.1),0px 7px 10px 1px rgba(0, 0, 0, 0.01),0px 2px 16px 1px rgba(0, 0, 0, 0.01);
}
.jss375 {
  box-shadow: 0px 5px 5px -3px rgba(0, 0, 0, 0.1),0px 8px 10px 1px rgba(0, 0, 0, 0.01),0px 3px 14px 2px rgba(0, 0, 0, 0.01);
}
.jss376 {
  box-shadow: 0px 5px 6px -3px rgba(0, 0, 0, 0.1),0px 9px 12px 1px rgba(0, 0, 0, 0.01),0px 3px 16px 2px rgba(0, 0, 0, 0.01);
}
.jss377 {
  box-shadow: 0px 6px 6px -3px rgba(0, 0, 0, 0.1),0px 10px 14px 1px rgba(0, 0, 0, 0.01),0px 4px 18px 3px rgba(0, 0, 0, 0.01);
}
.jss378 {
  box-shadow: 0px 6px 7px -4px rgba(0, 0, 0, 0.1),0px 11px 15px 1px rgba(0, 0, 0, 0.01),0px 4px 20px 3px rgba(0, 0, 0, 0.01);
}
.jss379 {
  box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.1),0px 12px 17px 2px rgba(0, 0, 0, 0.01),0px 5px 22px 4px rgba(0, 0, 0, 0.01);
}
.jss380 {
  box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.1),0px 13px 19px 2px rgba(0, 0, 0, 0.01),0px 5px 24px 4px rgba(0, 0, 0, 0.01);
}
.jss381 {
  box-shadow: 0px 7px 9px -4px rgba(0, 0, 0, 0.1),0px 14px 21px 2px rgba(0, 0, 0, 0.01),0px 5px 26px 4px rgba(0, 0, 0, 0.01);
}
.jss382 {
  box-shadow: 0px 8px 9px -5px rgba(0, 0, 0, 0.1),0px 15px 22px 2px rgba(0, 0, 0, 0.01),0px 6px 28px 5px rgba(0, 0, 0, 0.01);
}
.jss383 {
  box-shadow: 0px 8px 10px -5px rgba(0, 0, 0, 0.1),0px 16px 24px 2px rgba(0, 0, 0, 0.01),0px 6px 30px 5px rgba(0, 0, 0, 0.01);
}
.jss384 {
  box-shadow: 0px 8px 11px -5px rgba(0, 0, 0, 0.1),0px 17px 26px 2px rgba(0, 0, 0, 0.01),0px 6px 32px 5px rgba(0, 0, 0, 0.01);
}
.jss385 {
  box-shadow: 0px 9px 11px -5px rgba(0, 0, 0, 0.1),0px 18px 28px 2px rgba(0, 0, 0, 0.01),0px 7px 34px 6px rgba(0, 0, 0, 0.01);
}
.jss386 {
  box-shadow: 0px 9px 12px -6px rgba(0, 0, 0, 0.1),0px 19px 29px 2px rgba(0, 0, 0, 0.01),0px 7px 36px 6px rgba(0, 0, 0, 0.01);
}
.jss387 {
  box-shadow: 0px 10px 13px -6px rgba(0, 0, 0, 0.1),0px 20px 31px 3px rgba(0, 0, 0, 0.01),0px 8px 38px 7px rgba(0, 0, 0, 0.01);
}
.jss388 {
  box-shadow: 0px 10px 13px -6px rgba(0, 0, 0, 0.1),0px 21px 33px 3px rgba(0, 0, 0, 0.01),0px 8px 40px 7px rgba(0, 0, 0, 0.01);
}
.jss389 {
  box-shadow: 0px 10px 14px -6px rgba(0, 0, 0, 0.1),0px 22px 35px 3px rgba(0, 0, 0, 0.01),0px 8px 42px 7px rgba(0, 0, 0, 0.01);
}
.jss390 {
  box-shadow: 0px 11px 14px -7px rgba(0, 0, 0, 0.1),0px 23px 36px 3px rgba(0, 0, 0, 0.01),0px 9px 44px 8px rgba(0, 0, 0, 0.01);
}
.jss391 {
  box-shadow: 0px 11px 15px -7px rgba(0, 0, 0, 0.1),0px 24px 38px 3px rgba(0, 0, 0, 0.01),0px 9px 46px 8px rgba(0, 0, 0, 0.01);
}
</style><style data-jss="" data-meta="MuiPopover">
.jss478 {
  outline: none;
  position: absolute;
  min-width: 16px;
  max-width: calc(100% - 32px);
  overflow-y: auto;
  overflow-x: hidden;
  min-height: 16px;
  max-height: calc(100% - 32px);
}
</style><style data-jss="" data-meta="MuiButton">
.jss1132 {
  color: rgba(69, 90, 100, 0.87);
  padding: 8px 16px;
  font-size: 0.875rem;
  min-width: 64px;
  transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,border 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  min-height: 36px;
  box-sizing: border-box;
  line-height: 1.4em;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  font-weight: 500;
  border-radius: 4px;
  text-transform: uppercase;
}
.jss1132:hover {
  text-decoration: none;
  background-color: rgba(69, 90, 100, 0.08);
}
.jss1132.jss1152 {
  color: rgba(69, 90, 100, 0.26);
}
@media (hover: none) {
  .jss1132:hover {
    background-color: transparent;
  }
}
.jss1132:hover.jss1152 {
  background-color: transparent;
}
.jss1133 {
  width: 100%;
  display: inherit;
  align-items: inherit;
  justify-content: inherit;
}
.jss1135 {
  color: #4caf50;
}
.jss1135:hover {
  background-color: rgba(76, 175, 80, 0.08);
}
@media (hover: none) {
  .jss1135:hover {
    background-color: transparent;
  }
}
.jss1136 {
  color: #ab47bc;
}
.jss1136:hover {
  background-color: rgba(171, 71, 188, 0.08);
}
@media (hover: none) {
  .jss1136:hover {
    background-color: transparent;
  }
}
.jss1140 {
  border: 1px solid rgba(0, 0, 0, 0.23);
}
.jss1141 {
  border: 1px solid rgba(76, 175, 80, 0.5);
}
.jss1141:hover {
  border: 1px solid #4caf50;
}
.jss1142 {
  border: 1px solid rgba(171, 71, 188, 0.5);
}
.jss1142:hover {
  border: 1px solid #ab47bc;
}
.jss1143 {
  color: rgba(0, 0, 0, 0.87);
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.1),0px 2px 2px 0px rgba(0, 0, 0, 0.01),0px 3px 1px -2px rgba(0, 0, 0, 0.01);
  background-color: #90a4ae;
}
.jss1143.jss1151 {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 6px 10px 0px rgba(0, 0, 0, 0.01),0px 1px 18px 0px rgba(0, 0, 0, 0.01);
}
.jss1143:active {
  box-shadow: 0px 5px 5px -3px rgba(0, 0, 0, 0.1),0px 8px 10px 1px rgba(0, 0, 0, 0.01),0px 3px 14px 2px rgba(0, 0, 0, 0.01);
}
.jss1143.jss1152 {
  color: rgba(69, 90, 100, 0.26);
  box-shadow: none;
  background-color: rgba(69, 90, 100, 0.12);
}
.jss1143:hover {
  background-color: #cfd8dc;
}
@media (hover: none) {
  .jss1143:hover {
    background-color: #90a4ae;
  }
}
.jss1143:hover.jss1152 {
  background-color: rgba(69, 90, 100, 0.12);
}
.jss1144 {
  color: #fff;
  background-color: #4caf50;
}
.jss1144:hover {
  background-color: rgb(53, 122, 56);
}
@media (hover: none) {
  .jss1144:hover {
    background-color: #4caf50;
  }
}
.jss1145 {
  color: #fff;
  background-color: #ab47bc;
}
.jss1145:hover {
  background-color: rgb(119, 49, 131);
}
@media (hover: none) {
  .jss1145:hover {
    background-color: #ab47bc;
  }
}
.jss1149 {
  width: 56px;
  height: 56px;
  padding: 0;
  min-width: 0;
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 6px 10px 0px rgba(0, 0, 0, 0.01),0px 1px 18px 0px rgba(0, 0, 0, 0.01);
  border-radius: 50%;
}
.jss1149:active {
  box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.1),0px 12px 17px 2px rgba(0, 0, 0, 0.01),0px 5px 22px 4px rgba(0, 0, 0, 0.01);
}
.jss1150 {
  width: auto;
  height: 48px;
  padding: 0 16px;
  min-width: 48px;
  border-radius: 24px;
}
.jss1153 {
  color: inherit;
}
.jss1154 {
  width: 40px;
  height: 40px;
}
.jss1155 {
  padding: 7px 8px;
  min-width: 64px;
  font-size: 0.8125rem;
  min-height: 32px;
}
.jss1156 {
  padding: 8px 24px;
  min-width: 112px;
  font-size: 0.9375rem;
  min-height: 40px;
}
.jss1157 {
  width: 100%;
}
</style><style data-jss="" data-meta="MuiSvgIcon">
.jss420 {
  fill: currentColor;
  width: 1em;
  height: 1em;
  display: inline-block;
  font-size: 24px;
  transition: fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  user-select: none;
  flex-shrink: 0;
}
.jss421 {
  color: #4caf50;
}
.jss422 {
  color: #ab47bc;
}
.jss423 {
  color: rgba(69, 90, 100, 0.54);
}
.jss424 {
  color: #f44336;
}
.jss425 {
  color: rgba(69, 90, 100, 0.26);
}
.jss426 {
  font-size: inherit;
}
</style><style data-jss="" data-meta="MuiChip">
.jss1370 {
  color: rgba(0, 0, 0, 0.87);
  border: none;
  height: 32px;
  cursor: default;
  padding: 0;
  display: inline-flex;
  outline: none;
  font-size: 0.8125rem;
  transition: background-color 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  white-space: nowrap;
  align-items: center;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  border-radius: 16px;
  text-decoration: none;
  justify-content: center;
  background-color: #90a4ae;
}
.jss1371 {
  color: #fff;
  background-color: #4caf50;
}
.jss1372 {
  color: #fff;
  background-color: #ab47bc;
}
.jss1373 {
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.jss1373:hover, .jss1373:focus {
  background-color: rgb(152, 171, 180);
}
.jss1373:active {
  box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.1),0px 1px 1px 0px rgba(0, 0, 0, 0.01),0px 2px 1px -1px rgba(0, 0, 0, 0.01);
  background-color: rgb(157, 174, 183);
}
.jss1374:hover, .jss1374:focus {
  background-color: rgb(90, 181, 94);
}
.jss1374:active {
  background-color: rgb(97, 184, 101);
}
.jss1375:hover, .jss1375:focus {
  background-color: rgb(177, 85, 193);
}
.jss1375:active {
  background-color: rgb(181, 93, 196);
}
.jss1376:focus {
  background-color: rgb(152, 171, 180);
}
.jss1377:focus {
  background-color: rgb(111, 191, 115);
}
.jss1378:focus {
  background-color: rgb(187, 107, 201);
}
.jss1379 {
  border: 1px solid rgba(0, 0, 0, 0.23);
  background-color: transparent;
}
.jss1373.jss1379:hover, .jss1373.jss1379:focus, .jss1376.jss1379:focus {
  background-color: rgba(69, 90, 100, 0.08);
}
.jss1380 {
  color: #4caf50;
  border: 1px solid rgba(76, 175, 80, 0.5);
}
.jss1373.jss1380:hover, .jss1373.jss1380:focus, .jss1376.jss1380:focus {
  border: 1px solid #4caf50;
  background-color: rgba(76, 175, 80, 0.08);
}
.jss1381 {
  color: #ab47bc;
  border: 1px solid rgba(171, 71, 188, 0.5);
}
.jss1373.jss1381:hover, .jss1373.jss1381:focus, .jss1376.jss1381:focus {
  border: 1px solid #ab47bc;
  background-color: rgba(171, 71, 188, 0.08);
}
.jss1382 {
  width: 32px;
  color: #455a64;
  height: 32px;
  font-size: 1rem;
  margin-right: -4px;
}
.jss1383 {
  color: rgb(229, 229, 229);
  background-color: rgb(53, 122, 56);
}
.jss1384 {
  color: rgb(229, 229, 229);
  background-color: rgb(119, 49, 131);
}
.jss1385 {
  width: 19px;
  height: 19px;
}
.jss1386 {
  cursor: inherit;
  display: flex;
  align-items: center;
  user-select: none;
  white-space: nowrap;
  padding-left: 12px;
  padding-right: 12px;
}
.jss1387 {
  color: rgba(69, 90, 100, 0.26);
  cursor: pointer;
  height: auto;
  margin: 0 4px 0 -8px;
  -webkit-tap-highlight-color: transparent;
}
.jss1387:hover {
  color: rgba(69, 90, 100, 0.4);
}
.jss1388 {
  color: rgba(255, 255, 255, 0.65);
}
.jss1388:hover, .jss1388:active {
  color: #fff;
}
.jss1389 {
  color: rgba(255, 255, 255, 0.65);
}
.jss1389:hover, .jss1389:active {
  color: #fff;
}
.jss1390 {
  color: rgba(76, 175, 80, 0.65);
}
.jss1390:hover, .jss1390:active {
  color: #4caf50;
}
.jss1391 {
  color: rgba(171, 71, 188, 0.65);
}
.jss1391:hover, .jss1391:active {
  color: #ab47bc;
}
</style><style data-jss="" data-meta="MuiDialog">
.jss599 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.jss600 {
  overflow-y: auto;
  overflow-x: hidden;
}
.jss601 {
  margin: 48px;
  display: flex;
  outline: none;
  position: relative;
  overflow-y: auto;
  flex-direction: column;
}
.jss602 {
  flex: 0 1 auto;
  max-height: calc(100% - 96px);
}
.jss603 {
  margin: 48px auto;
}
.jss604 {
  max-width: 360px;
}
@media (max-width:455.95px) {
  .jss604.jss603 {
    margin: 48px;
  }
}
.jss605 {
  max-width: 576px;
}
@media (max-width:671.95px) {
  .jss605.jss603 {
    margin: 48px;
  }
}
.jss606 {
  max-width: 768px;
}
@media (max-width:863.95px) {
  .jss606.jss603 {
    margin: 48px;
  }
}
.jss607 {
  max-width: 992px;
}
@media (max-width:1087.95px) {
  .jss607.jss603 {
    margin: 48px;
  }
}
.jss608 {
  width: 100%;
}
.jss609 {
  width: 100%;
  margin: 0;
  height: 100%;
  max-width: 100%;
  max-height: none;
  border-radius: 0;
}
.jss609.jss603 {
  margin: 0;
}
</style><style data-jss="" data-meta="MuiDivider">
.jss650 {
  height: 1px;
  margin: 0;
  border: none;
  flex-shrink: 0;
  background-color: rgba(69, 90, 100, 0.12);
}
.jss651 {
  left: 0;
  width: 100%;
  bottom: 0;
  position: absolute;
}
.jss652 {
  margin-left: 72px;
}
.jss653 {
  background-color: rgba(69, 90, 100, 0.08);
}
</style><style data-jss="" data-meta="MuiTab">
.jss1058 {
  color: rgba(69, 90, 100, 0.87);
  padding: 0;
  position: relative;
  overflow: hidden;
  font-size: 0.875rem;
  max-width: 264px;
  min-width: 72px;
  min-height: 48px;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  flex-shrink: 0;
  font-weight: 500;
  white-space: normal;
  text-transform: uppercase;
}
@media (min-width:768px) {
  .jss1058 {
    font-size: 0.8125rem;
    min-width: 160px;
  }
}
.jss1059 {
  min-height: 72px;
}
.jss1060 {
  color: inherit;
  opacity: 0.7;
}
.jss1060.jss1063 {
  opacity: 1;
}
.jss1060.jss1064 {
  opacity: 0.4;
}
.jss1061 {
  color: rgba(69, 90, 100, 0.54);
}
.jss1061.jss1063 {
  color: #4caf50;
}
.jss1061.jss1064 {
  color: rgba(69, 90, 100, 0.38);
}
.jss1062 {
  color: rgba(69, 90, 100, 0.54);
}
.jss1062.jss1063 {
  color: #ab47bc;
}
.jss1062.jss1064 {
  color: rgba(69, 90, 100, 0.38);
}
.jss1065 {
  flex-grow: 1;
  max-width: none;
  flex-shrink: 1;
}
.jss1066 {
  width: 100%;
  display: inline-flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.jss1067 {
  padding-top: 6px;
  padding-left: 12px;
  padding-right: 12px;
  padding-bottom: 6px;
}
@media (min-width:768px) {
  .jss1067 {
    padding-left: 24px;
    padding-right: 24px;
  }
}
@media (max-width:767.95px) {
  .jss1069 {
    font-size: 0.75rem;
  }
}
</style><style data-jss="">
.jss1070 {
  width: 100%;
  height: 2px;
  bottom: 0;
  position: absolute;
  transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  will-change: left, width;
}
.jss1071 {
  background-color: #4caf50;
}
.jss1072 {
  background-color: #ab47bc;
}
</style><style data-jss="" data-meta="MuiTabs">
.jss1049 {
  overflow: hidden;
  min-height: 48px;
  -webkit-overflow-scrolling: touch;
}
.jss1050 {
  display: flex;
}
.jss1051 {
  justify-content: center;
}
.jss1052 {
  flex: 1 1 auto;
  display: inline-block;
  position: relative;
  white-space: nowrap;
}
.jss1053 {
  width: 100%;
  overflow-x: hidden;
}
.jss1054 {
  overflow-x: scroll;
}
@media (max-width:575.95px) {
  .jss1056 {
    display: none;
  }
}
</style><style data-jss="" data-meta="MuiAppBar">
.jss357 {
  width: 100%;
  display: flex;
  z-index: 1100;
  box-sizing: border-box;
  flex-shrink: 0;
  flex-direction: column;
}
.jss358 {
  top: 0;
  left: auto;
  right: 0;
  position: fixed;
}
.jss359 {
  top: 0;
  left: auto;
  right: 0;
  position: absolute;
}
.jss360 {
  top: 0;
  left: auto;
  right: 0;
  position: sticky;
}
.jss361 {
  position: static;
}
.jss362 {
  color: rgba(0, 0, 0, 0.87);
  background-color: #cfd8dc;
}
.jss363 {
  color: #fff;
  background-color: #4caf50;
}
.jss364 {
  color: #fff;
  background-color: #ab47bc;
}
</style><style data-jss="" data-meta="MuiToolbar">
.jss407 {
  display: flex;
  position: relative;
  align-items: center;
}
.jss408 {
  padding-left: 16px;
  padding-right: 16px;
}
@media (min-width:576px) {
  .jss408 {
    padding-left: 24px;
    padding-right: 24px;
  }
}
.jss409 {
  min-height: 56px;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss409 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss409 {
    min-height: 64px;
  }
}
.jss410 {
  min-height: 48px;
}
</style><style data-jss="" data-meta="MuiDrawer">
.jss493 {
  flex: 0 0 auto;
}
.jss494 {
  top: 0;
  flex: 1 0 auto;
  height: 100%;
  display: flex;
  z-index: 1200;
  outline: none;
  position: fixed;
  overflow-y: auto;
  flex-direction: column;
  -webkit-overflow-scrolling: touch;
}
.jss495 {
  left: 0;
  right: auto;
}
.jss496 {
  left: auto;
  right: 0;
}
.jss497 {
  top: 0;
  left: 0;
  right: 0;
  bottom: auto;
  height: auto;
  max-height: 100%;
}
.jss498 {
  top: auto;
  left: 0;
  right: 0;
  bottom: 0;
  height: auto;
  max-height: 100%;
}
.jss499 {
  border-right: 1px solid rgba(69, 90, 100, 0.12);
}
.jss500 {
  border-bottom: 1px solid rgba(69, 90, 100, 0.12);
}
.jss501 {
  border-left: 1px solid rgba(69, 90, 100, 0.12);
}
.jss502 {
  border-top: 1px solid rgba(69, 90, 100, 0.12);
}
</style><style data-jss="" data-meta="MuiCollapse">
.jss571 {
  height: 0;
  overflow: hidden;
  transition: height 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss572 {
  height: auto;
}
.jss573 {
  display: flex;
}
.jss574 {
  width: 100%;
}
</style><style data-jss="" data-meta="MuiListItemIcon">
.jss564 {
  color: rgba(69, 90, 100, 0.54);
  flex-shrink: 0;
  margin-right: 16px;
}
</style><style data-jss="" data-meta="XButton">
.jss1121 {
  display: inline-block;
  position: relative;
}
.jss1122 {
  display: block;
  position: relative;
}
.jss1123 {
  top: 50%;
  left: 50%;
  position: absolute;
  margin-top: -12px;
  margin-left: -12px;
}
.jss1124 {
  margin-top: 8px;
}
.jss1125 {
  margin-right: 8px;
}
.jss1126 {
  margin-bottom: 8px;
}
.jss1127 {
  margin-left: 8px;
}
.jss1128 {
  width: 100%;
}
.jss1129 {
  border-width: 1px;
  border-style: solid;
}
.jss1130 {
  right: 24px;
  bottom: 24px;
  position: fixed;
}
.jss1131 {
  padding: 16px;
  min-height: 56px;
}
</style><style data-jss="" data-meta="XChip">
.jss1355 {
  max-width: 100%;
  white-space: normal;
}
.jss1356 {
  height: 28px;
  border-radius: 14px;
}
.jss1357 {
  height: 32px;
  border-radius: 16px;
}
.jss1358 {
  height: 36px;
  border-radius: 18px;
}
.jss1359 {
  width: 28px;
  height: 28px;
}
.jss1360 {
  width: 32px;
  height: 32px;
}
.jss1361 {
  width: 36px;
  height: 36px;
}
.jss1362 {
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
}
.jss1363 {
  margin: 0 2px 0 -8px;
}
.jss1364 {
  margin: 0 4px 0 -8px;
}
.jss1365 {
  margin: 0 4px 0 -8px;
}
.jss1366 {
  color: rgba(0, 0, 0, 0.87);
  background-color: #cfd8dc;
}
.jss1367 {
  background-color: rgba(69, 90, 100, 0.26);
}
.jss1368 {
  color: rgba(69, 90, 100, 0.26);
}
.jss1368:hover {
  color: rgba(69, 90, 100, 0.4);
}
.jss1369:focus {
  background-color: rgb(190, 198, 202);
}
</style><style data-jss="" data-meta="XDivider">
.jss1037 {
  margin-top: 8px !important;
}
.jss1038 {
  margin-top: 16px !important;
}
.jss1039 {
  margin-top: 24px !important;
}
.jss1040 {
  margin-left: -8px !important;
  margin-right: -8px !important;
}
.jss1041 {
  margin-left: -16px !important;
  margin-right: -16px !important;
}
.jss1042 {
  margin-left: -24px !important;
  margin-right: -24px !important;
}
</style><style data-jss="" data-meta="XTypography">
.jss438 {
  display: inline;
}
.jss439 {
  display: block;
  margin-top: 8px;
}
.jss440 {
  margin-top: 8px !important;
}
.jss441 {
  margin-top: 16px !important;
}
.jss442 {
  margin-top: 24px !important;
}
.jss443 {
  margin-bottom: 8px !important;
}
.jss444 {
  margin-bottom: 16px !important;
}
.jss445 {
  margin-bottom: 24px !important;
}
.jss446 {
  cursor: pointer;
}
.jss447 {
  border: none;
  background: transparent;
}
</style><style data-jss="" data-meta="XDisplayInfo">
.jss994 {
  display: flex;
  min-height: 36px;
  align-items: center;
}
.jss995 {
  margin-top: 12px;
}
.jss996 {
  margin-top: 16px;
}
.jss997 {
  margin-top: 24px;
}
.jss998 {
  flex: 1;
  width: 100%;
  word-break: break-all;
}
.jss999 {
  display: inline-flex;
  margin-right: 4px;
}
.jss1000 {
  display: inline-flex;
  margin-left: 4px;
}
</style><style data-jss="" data-meta="XPaper">
.jss620 {
  padding: 16px;
}
.jss621 {
  background-color: #fff;
}
.jss622 {
  background-color: #eceff1;
}
.jss623 {
  width: 100%;
}
.jss624 {
  margin-top: 8px !important;
}
.jss625 {
  margin-top: 16px !important;
}
.jss626 {
  margin-top: 24px !important;
}
.jss627 {
  margin-bottom: 8px !important;
}
.jss628 {
  margin-bottom: 16px !important;
}
.jss629 {
  margin-bottom: 24px !important;
}
</style><style data-jss="" data-meta="XTabContainer">
.jss1073 {
  padding: 24px;
}
</style><style data-jss="" data-meta="XTabs">
.jss1046 {
  position: relative;
}
.jss1046:after {
  width: 100%;
  bottom: 0;
  height: 1px;
  content: "";
  z-index: 1;
  position: absolute;
  background-color: rgba(69, 90, 100, 0.12);
}
.jss1047 {
  width: 100%;
  z-index: 2;
  position: fixed;
  background-color: #fff;
}
.jss1048 {
  height: 48px;
}
</style><style data-jss="" data-meta="XDrawerAppBar">
.jss353 {
  background-color: #fff;
  border-bottom-color: rgba(232, 235, 236, 1);
  border-bottom-style: solid;
  border-bottom-width: 1px;
}
@media (min-width:768px) {
  .jss353 {
    width: calc(100% - 0px);
    z-index: 1201;
  }
}
@media (min-width:768px) {
  .jss354 {
    width: calc(100% - 210px);
    margin-left: 210px;
  }
}
@media (min-width:576px) {
  .jss355 {
    padding: 8px;
  }
}
.jss356 {
  margin: 0 4px 0 0;
}
@media (min-width:576px) {
  .jss356 {
    margin: 0 4px;
  }
}
</style><style data-jss="" data-meta="XDrawerMenuItem">
.jss538 {
  width: 100%;
}
.jss539 {
  padding-left: 8px;
}
.jss539:hover {
  background: rgb(23, 30, 33);
}
.jss540 {
  color: #cfd8dc;
}
.jss541 {
  color: #4caf50;
}
.jss542 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss543 {
  color: #cfd8dc;
}
.jss544 {
  color: #4caf50;
}
.jss545 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss546 {
  padding-left: 0;
}
.jss547:first-child {
  padding-left: 16px;
}
.jss548 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss549 {
  background: rgb(28, 37, 41);
}
.jss550 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss551 {
  border-left: 3px solid transparent;
}
.jss551:hover {
  background: rgb(42, 54, 61);
}
.jss552 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawerCallapseItem">
.jss523 {
  width: 100%;
}
.jss524 {
  padding-left: 8px;
}
.jss524:hover {
  background: rgb(23, 30, 33);
}
.jss525 {
  color: #cfd8dc;
}
.jss526 {
  color: #4caf50;
}
.jss527 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss528 {
  color: #cfd8dc;
}
.jss529 {
  color: #4caf50;
}
.jss530 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss531 {
  padding-left: 0;
}
.jss532:first-child {
  padding-left: 16px;
}
.jss533 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss534 {
  background: rgb(28, 37, 41);
}
.jss535 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss536 {
  border-left: 3px solid transparent;
}
.jss536:hover {
  background: rgb(42, 54, 61);
}
.jss537 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawerMenu">
.jss504 {
  width: 100%;
}
.jss505 {
  padding-left: 8px;
}
.jss505:hover {
  background: rgb(23, 30, 33);
}
.jss506 {
  color: #cfd8dc;
}
.jss507 {
  color: #4caf50;
}
.jss508 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss509 {
  color: #cfd8dc;
}
.jss510 {
  color: #4caf50;
}
.jss511 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss512 {
  padding-left: 0;
}
.jss513:first-child {
  padding-left: 16px;
}
.jss514 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss515 {
  background: rgb(28, 37, 41);
}
.jss516 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss517 {
  border-left: 3px solid transparent;
}
.jss517:hover {
  background: rgb(42, 54, 61);
}
.jss518 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawer">
.jss486 {
  width: 210px;
  border: 0;
  background: rgb(48, 62, 69);
  overflow-x: hidden;
}
.jss487 {
  top: 56px;
  width: 210px;
  height: calc(100% - 56px);
  position: fixed;
  overflow-y: auto;
}
@media (min-width:576px) {
  .jss487 {
    top: 64px;
    height: calc(100% - 64px);
  }
}
@media (min-width:768px) {
  .jss487 {
    position: absolute;
  }
  .jss487::-webkit-scrollbar-track {
    box-shadow: none;
    background-color: transparent;
  }
  .jss487::-webkit-scrollbar {
    width: 8px;
  }
  .jss487::-webkit-scrollbar-thumb {
    box-shadow: none;
    border-radius: 0;
    background-color: rgb(81, 91, 95);
  }
}
.jss488 {
  width: 0;
}
.jss489 {
  color: #fff;
  display: flex;
  background: rgb(48, 62, 69);
  min-height: 56px;
  align-items: center;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss489 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss489 {
    min-height: 64px;
  }
}
.jss490 {
  width: 32px;
  height: 32px;
  margin: 0 12px;
}
.jss491 {
  width: 100%;
  cursor: pointer;
  border: 0;
  display: flex;
  min-height: 56px;
  align-items: center;
  padding-top: 0;
  padding-left: 0;
  padding-right: 0;
  padding-bottom: 0;
  background-color: transparent;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss491 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss491 {
    min-height: 64px;
  }
}
.jss491:hover {
  text-decoration: none;
}
.jss492 {
  color: #fff;
  font-size: 1.25rem;
}
</style><style data-jss="" data-meta="XVirtualizedSelect">
.Select.is-focused:not(.is-open) > .Select-control, .Select.is-open .Select-control {
  box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25);
  border-color: #4caf50;
}
.Select-control {
  color: rgba(69, 90, 100, 0.87);
  height: auto;
  display: flex;
  font-size: 0.875rem;
  min-height: 36px;
  transition: border-color 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  border-color: #cfd8dc;
  border-radius: 2px !important;
  background-color: #fff;
}
.Select-control .Select-input:focus {
  background: inherit;
}
.Select-multi-value-wrapper {
  width: calc(100% - 24px);
  display: inline-flex !important;
  flex-wrap: wrap;
  align-items: center;
}
.Select.has-value.is-clearable.Select--multi .Select-multi-value-wrapper {
  width: calc(100% - 48px);
  padding-right: 6px;
}
.Select.has-value.Select--multi .Select-multi-value-wrapper {
  padding-bottom: 3px;
}
.Select-arrow-zone, .Select-clear-zone, .Select--multi .Select-clear-zone {
  color: rgba(69, 90, 100, 0.54);
  width: 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.Select-clear-zone:hover {
  color: currentColor;
}
.Select-values {
  display: inline-flex;
  max-width: 100%;
  margin-top: 3px;
  margin-left: 3px;
}
.Select-input {
  height: 34px;
  display: inline-flex !important;
  padding: 0 12px;
}
.Select--multi.has-value .Select-input {
  height: 28px;
  margin-top: 3px;
  margin-left: 3px;
}
.Select-input > input, .Select-control > *:last-child {
  padding: 0;
}
.Select-placeholder, .Select--single > .Select-control .Select-value {
  color: rgba(69, 90, 100, 0.87);
  width: calc(100% - 24px);
  padding-left: 12px;
}
.Select-placeholder {
  opacity: 0.42;
}
.Select-menu-outer {
  top: calc(100% + 8px);
  left: 0;
  width: 100%;
  border: 0;
  z-index: 2;
  position: absolute;
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.1),0px 2px 2px 0px rgba(0, 0, 0, 0.01),0px 3px 1px -2px rgba(0, 0, 0, 0.01);
  max-height: 216px;
  background-color: #fff;
}
.Select-noresults {
  padding: 16px;
}
.Select.is-disabled > .Select-control {
  background: #eceff1;
}
.Select.is-disabled.Select--multi.has-value .Select-input {
  display: none;
}
.Select.is-disabled .Select-placeholder, .Select.is-disabled .Select-value {
  color: rgba(69, 90, 100, 0.38);
  opacity: 1;
}
.Select.is-disabled .Select-arrow-zone {
  opacity: 1;
}
.Select.is-disabled .Select-multi-value-wrapper {
  display: inline-block !important;
}
.jss1043 {
  margin-top: 24px;
}
.jss1044 .Select-control {
  border-color: #f44336 !important;
}
.jss1044.is-focused .Select-control {
  box-shadow: 0 0 0 0.2rem rgba(244, 67, 54, 0.25) !important;
}
.jss1045 {
  color: #ab47bc;
  font-weight: 500;
  text-transform: uppercase;
}
</style><style data-jss="" data-meta="MuiExpansionPanel">
.jss1017 {
  position: relative;
  transition: margin 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss1017:before {
  top: -1px;
  left: 0;
  right: 0;
  height: 1px;
  content: "";
  opacity: 1;
  position: absolute;
  transition: opacity 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  background-color: rgba(69, 90, 100, 0.12);
}
.jss1017:first-child {
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
}
.jss1017:last-child {
  border-bottom-left-radius: 2px;
  border-bottom-right-radius: 2px;
}
.jss1017.jss1018 + .jss1017:before {
  display: none;
}
@supports (-ms-ime-align: auto) {
  .jss1017:last-child {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }
}
.jss1017:first-child:before {
  display: none;
}
.jss1018 {
  margin: 16px 0;
}
.jss1018:first-child {
  margin-top: 0;
}
.jss1018:last-child {
  margin-bottom: 0;
}
.jss1018:before {
  opacity: 0;
}
.jss1019 {
  background-color: rgba(69, 90, 100, 0.12);
}
</style><style data-jss="" data-meta="MuiExpansionPanelDetails">
.jss1026 {
  display: flex;
  padding: 8px 24px 24px;
}
</style><style data-jss="" data-meta="MuiExpansionPanelSummary">
.jss1020 {
  display: flex;
  padding: 0 24px 0 24px;
  min-height: 48px;
  transition: min-height 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss1020:hover:not(.jss1023) {
  cursor: pointer;
}
.jss1020.jss1021 {
  min-height: 64px;
}
.jss1020.jss1022 {
  background-color: #90a4ae;
}
.jss1020.jss1023 {
  opacity: 0.38;
}
.jss1024 {
  margin: 12px 0;
  display: flex;
  flex-grow: 1;
  transition: margin 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss1024 > :last-child {
  padding-right: 32px;
}
.jss1024.jss1021 {
  margin: 20px 0;
}
.jss1025 {
  top: 50%;
  right: 8px;
  position: absolute;
  transform: translateY(-50%) rotate(0deg);
  transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss1025:hover {
  background-color: transparent;
}
.jss1025.jss1021 {
  transform: translateY(-50%) rotate(180deg);
}
</style><style data-jss="">
.jss1027 {
  border-bottom-style: solid;
  border-bottom-width: 1px;
  border-bottom-color: #cfd8dc;
}
.jss1028 {
  padding: 16px;
  margin-top: 16px;
  background: #cfd8dc;
  text-align: center;
}
.jss1029 {
  margin-left: 32px;
}
.jss1030 {
  display: flex;
  margin-top: 4px;
  justify-content: space-between;
}
.jss1031 {
  margin-top: 8px;
}
.jss1032 {
  display: flex;
  margin-top: 4px;
  justify-content: space-between;
}
.jss1033 {
  margin-left: 32px;
}
.jss1034 {
  margin-top: 16px;
  margin-left: 32px;
  margin-bottom: 16px;
}
.jss1035 {
  color: #546e7a;
  margin-right: 8px;
}
.jss1036 {
  margin-top: 8px;
}
</style><style data-jss="">
.jss992 {
  display: block;
  background: #eceff1;
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.1),0px 2px 2px 0px rgba(0, 0, 0, 0.01),0px 3px 1px -2px rgba(0, 0, 0, 0.01);
}
.jss993 {
  background: #eceff1;
}
</style><style data-jss="">
.jss596 {
  margin: 24px;
  max-width: 576px;
  max-height: 490px;
}
.jss597 {
  padding-left: 16px;
  padding-right: 16px;
}
</style><style data-jss="">
.jss595 {
  height: 32px;
  display: flex;
  background: #fff9c4;
  align-items: center;
  justify-content: center;
}
</style><style data-jss="">
.jss575 {
  top: 56px;
  width: 100%;
  z-index: 2;
  position: fixed;
  box-shadow: 0px 4px 8px -3px rgba(232, 235, 236, 1);
}
@media (min-width:0px) and (orientation: landscape) {
  .jss575 {
    top: 48px;
  }
}
@media (min-width:576px) {
  .jss575 {
    top: 64px;
  }
}
.jss576 {
  height: 40px;
  display: flex;
  background: #fff;
  align-items: center;
}
@media (min-width:768px) {
  .jss576 {
    padding-left: 8px;
  }
}
@media (min-width:576px) {
  .jss576 {
    justify-content: space-between;
  }
}
.jss577 {
  width: 100%;
}
@media (min-width:768px) {
  .jss577 {
    width: calc(100% - 210px);
  }
}
.jss578 {
  display: none;
}
@media (min-width:576px) {
  .jss578 {
    display: flex;
    align-items: center;
  }
}
.jss579 {
  display: flex;
  align-items: center;
}
@media (min-width:0px) and (max-width:575.95px) {
  .jss579 {
    flex: 1;
    padding-left: 8px;
    padding-right: 8px;
    justify-content: space-between;
  }
}
.jss580 {
  display: none;
}
@media (min-width:576px) {
  .jss580 {
    display: flex;
  }
}
.jss581 {
  display: none;
}
@media (min-width:992px) {
  .jss581 {
    display: flex;
  }
}
.jss582 {
  display: none;
}
@media (min-width:1200px) {
  .jss582 {
    display: flex;
  }
}
.jss583 {
  width: 16px;
  color: rgba(69, 90, 100, 0.54);
  height: 16px;
  margin-left: 8px;
  margin-right: 8px;
}
.jss584 {
  font-size: 0.75rem;
  font-weight: 300;
}
.jss584 span {
  font-weight: 400;
}
.jss585 {
  margin-right: 8px;
}
@media (min-width:576px) {
  .jss586 {
    margin-left: 8px;
    margin-right: 8px;
  }
}
.jss586:hover {
  background: transparent;
}
.jss587 {
  cursor: help;
}
</style><style data-jss="" data-meta="XPageHeader">
.jss610 {
  background: #fff;
  border-bottom-color: rgba(232, 235, 236, 1);
  border-bottom-style: solid;
  border-bottom-width: 1px;
}
.jss611 {
  margin-bottom: 8px;
}
@media (min-width:576px) {
  .jss611 {
    margin-bottom: 16px;
  }
}
@media (min-width:992px) {
  .jss611 {
    margin-bottom: 24px;
  }
}
.jss612 {
  color: rgba(69, 90, 100, 0.87);
}
.jss613 {
  height: 40px;
  display: flex;
  align-items: center;
  font-weight: 400;
  padding-top: 16px;
  padding-left: 16px;
}
@media (min-width:768px) {
  .jss613 {
    height: 48px;
  }
}
.jss614 {
  height: 48px;
  display: inline-flex;
  font-size: 0.75rem;
  align-items: center;
  font-weight: 500;
  padding-left: 16px;
  border-bottom: 2px solid #4caf50;
  padding-right: 16px;
}
@media (min-width:768px) {
  .jss614 {
    font-size: 0.8125rem;
  }
}
</style><style data-jss="" data-meta="MuiSnackbar">
.jss4 {
  left: 0;
  right: 0;
  z-index: 1400;
  display: flex;
  position: fixed;
  align-items: center;
  justify-content: center;
}
.jss5 {
  top: 0;
}
@media (min-width:768px) {
  .jss5 {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
  }
}
.jss6 {
  bottom: 0;
}
@media (min-width:768px) {
  .jss6 {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
  }
}
.jss7 {
  top: 0;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss7 {
    top: 24px;
    left: auto;
    right: 24px;
  }
}
.jss8 {
  bottom: 0;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss8 {
    left: auto;
    right: 24px;
    bottom: 24px;
  }
}
.jss9 {
  top: 0;
  justify-content: flex-start;
}
@media (min-width:768px) {
  .jss9 {
    top: 24px;
    left: 24px;
    right: auto;
  }
}
.jss10 {
  bottom: 0;
  justify-content: flex-start;
}
@media (min-width:768px) {
  .jss10 {
    left: 24px;
    right: auto;
    bottom: 24px;
  }
}
</style><style data-jss="">
.jss1 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style><style data-jss="">
.jss1353 {
  color: #fafafa;
  padding: 4px 8px;
  font-size: 14px;
  font-weight: 500;
  border-radius: 2px;
  background-color: #f44336;
}
.jss1354 {
  color: #fafafa;
  padding: 4px 8px;
  font-size: 14px;
  font-weight: 500;
  border-radius: 2px;
  background-color: #388e3c;
}
</style><style data-jss="">
.jss1345 {
  z-index: 0;
  position: relative;
  margin-top: 24px;
  text-align: center;
}
.jss1345:after {
  top: 0;
  left: 50%;
  bottom: 0;
  content: "";
  z-index: -1;
  position: absolute;
  border-left: 1px solid #cfd8dc;
}
.jss1346 {
  width: 16px;
  height: 16px;
  margin: 0 auto;
  border: 2px solid #f44336;
  border-radius: 50%;
}
.jss1347 {
  width: 16px;
  height: 16px;
  margin: 0 auto;
  border: 2px solid #4caf50;
  border-radius: 50%;
}
.jss1348 {
  display: block;
  background: white;
  margin-bottom: 28px;
}
.jss1349 {
  display: inline-flex;
  margin-right: 8px;
  margin-bottom: 8px;
}
@media (min-width:992px) {
  .jss1350 {
    padding: 0 70px;
  }
}
.jss1351 {
  text-align: left;
}
.jss1352 {
  text-align: center;
  margin-top: 16px;
  margin-bottom: 16px;
}
</style><style data-jss="">
.jss975 {
  margin-top: 16px;
}
.jss976 {
  padding: 6px;
}
.pswp-thumbnail {
  float: left;
}
.jss977 {
  border-width: 1px;
  border-color: #eceff1;
  border-style: solid;
}
.jss978 {
  border: 0;
  cursor: pointer;
  display: inline-block;
  background: transparent;
  text-decoration: none;
}
.jss978:hover {
  text-decoration: none;
}
.jss979 {
  color: #90a4ae;
  overflow: hidden;
  font-size: 13px;
  word-wrap: break-word;
  max-width: 150px;
  max-height: 70px;
  margin-top: 8px;
  text-align: center;
  min-height: 45px;
  line-height: 1.2;
  margin-bottom: 0;
  text-overflow: ellipsis;
}
.jss980 {
  float: left;
  cursor: pointer;
  max-width: 150px;
  margin-top: 16px;
  margin-right: 16px;
}
.jss981 {
  display: block;
  overflow: hidden;
  max-height: 30px;
}
</style><style data-jss="">
.jss645 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.jss646 {
  display: flex;
  justify-content: space-between;
}
.jss648 {
  display: block;
}
.jss649 {
  margin-top: 40px;
}
</style><style data-jss="">
.jss481 {
  display: flex;
  padding: 16px;
}
.jss482 {
  width: calc(100% - 96px);
  display: flex;
  padding-left: 16px;
  flex-direction: column;
  justify-content: space-between;
}
.jss483 {
  width: 96px;
  height: 96px;
  background: #90a4ae;
}
.jss484 {
  color: #fff;
}
@media (min-width:576px) {
  .jss485 {
    max-width: 400px;
  }
}
</style><style data-jss="">
.jss473 {
  width: 208px;
  display: flex;
  flex-wrap: wrap;
}
@media (min-width:576px) {
  .jss473 {
    width: 100%;
    max-width: 312px;
    min-width: 208px;
  }
}
.jss474 {
  background: #fff;
  padding-top: 16px;
  padding-left: 16px;
  padding-right: 16px;
}
.jss475 {
  width: 104px;
  border: 1px solid transparent;
  cursor: pointer;
  display: flex;
  padding: 8px;
  background: transparent;
  align-items: center;
  margin-bottom: 16px;
  flex-direction: column;
  justify-content: space-between;
  text-decoration: none;
}
.jss475:hover {
  border-color: rgba(69, 90, 100, 0.12);
  text-decoration: none;
}
.jss475:disabled {
  cursor: not-allowed;
  opacity: 0.55;
  border-color: transparent;
}
.jss476 {
  width: 36px;
  height: 36px;
}
.jss477 {
  height: 37px;
  display: flex;
  font-size: 0.8125rem;
  align-items: center;
  line-height: 1.4;
}
</style><style data-jss="">
.jss434 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss434 {
    margin-left: 16px;
    margin-right: 8px;
    justify-content: space-between;
  }
}
.jss435 {
  height: 24px;
}
@media (min-width:576px) {
  .jss435 {
    height: 28px;
  }
}
@media (min-width:768px) {
  .jss435 {
    height: 32px;
  }
}
.jss436 {
  margin-left: 4px;
}
.jss437 {
  display: flex;
  align-items: center;
}
@media (max-width:767.95px) {
  .jss437 {
    display: none;
  }
}
</style><style data-jss="" data-meta="Wrapper">
.jss349 {
  color: #fff;
  margin: 0 auto;
  display: flex;
  user-select: none;
}
.jss349:hover {
  color: #fff;
  text-decoration: none;
}
.jss350 {
  margin-left: 8px;
}
.jss351 {
  font-size: 1.25rem;
  font-weight: 400;
  line-height: 1;
  letter-spacing: 1px;
}
.jss352 {
  font-size: 0.875rem;
  font-weight: 300;
  line-height: 1;
  letter-spacing: 1px;
}
</style><style data-jss="">
.jss345 {
  flex: 1;
  display: flex;
}
.jss346 {
  min-height: 56px;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss346 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss346 {
    min-height: 64px;
  }
}
.jss347 {
  flex: 1;
}
.jss348 {
  flex: 1;
  display: flex;
  min-height: 100vh;
  flex-direction: column;
}
</style><style id="detectElementResize" type="text/css">@keyframes resizeanim { from { opacity: 0; } to { opacity: 0; } } .resize-triggers { animation: 1ms resizeanim; visibility: hidden; opacity: 0; } .resize-triggers, .resize-triggers > div, .contract-trigger:before { content: " "; display: block; position: absolute; top: 0; left: 0; height: 100%; width: 100%; overflow: hidden; z-index: -1; } .resize-triggers > div { background: #eee; overflow: auto; } .contract-trigger:before { width: 200%; height: 200%; }</style></head><body class="drawer-md-open" style=""><div id="root" class="root"><div class="jss345"><header class="jss365 jss367 jss357 jss358 jss363 mui-fixed jss353 jss354" id="xdrawer-app-bar" style="padding-right: 0px;"><div class="jss399"><div class="jss407 jss409 jss355"><button tabindex="0" class="jss417 jss411 jss356" type="button" aria-label="open drawer"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span><span class="jss427"></span></button><div class="jss434"><div class="jss437"><button tabindex="0" class="jss417 jss411" type="button" aria-label="MENU"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span></button><span class="jss448 jss458 jss446 jss436">MENU</span></div><div><button tabindex="0" class="jss417 jss411" type="button" aria-haspopup="true" aria-label="Apps"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></button><button tabindex="0" class="jss417 jss411" type="button" aria-haspopup="true" aria-label="Minha Conta"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></button></div></div></div></div><div class="jss397"><div class="jss407 jss409"><div class="jss434"><div class="jss437"><button tabindex="0" class="jss417 jss411" type="button" aria-label="MENU"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span></button><span class="jss448 jss458 jss446 jss436">MENU</span></div><div><button tabindex="0" class="jss417 jss411" type="button" aria-haspopup="true" aria-label="Apps"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></button><button tabindex="0" class="jss417 jss411" type="button" aria-haspopup="true" aria-label="Minha Conta"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></button></div></div></div></div></header><div class="jss397"><div class="jss486"></div><div class="jss493"><div class="jss365 jss367 jss494 jss486 jss495 jss499"><header class="jss489"><a class="jss349" href="/"><img src="/static/media/vendas-logo-outline.7bf3fae0.svg" width="32" height="32" alt="Conexão Vendas"><div class="jss350"><p class="jss448 jss457 jss467 jss352">conexão</p><p class="jss448 jss457 jss467 jss351">Vendas</p></div></a></header><div class="jss487"><ul class="jss519 jss520 jss504"><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Venda</span></div><svg class="jss420 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><defs><path id="a" d="M0 0h24v24H0V0z"></path></defs><path d="M14 10H2v2h12v-2zm0-4H2v2h12V6zM2 16h8v-2H2v2zm19.5-4.5L23 13l-6.99 7-4.51-4.5L13 14l3.01 3 5.49-5.5z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Viabilidade</span></div><svg class="jss420 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.11,16.42A6.9,6.9,0,1,1,7.58,8.89c0-.23.3-.41.3-.64s-.34-.45-.3-.67a8.22,8.22,0,1,0,8.88,8.84c-.22,0-.45-.3-.67-.3S15.34,16.46,15.11,16.42Z"></path><path d="M24,8.25A8.24,8.24,0,0,0,7.54,7.58c.22,0,.45.3.67.3s.41-.34.64-.3a6.92,6.92,0,0,1,13.8.67,6.91,6.91,0,0,1-6.22,6.86c0,.23-.3.41-.3.64s.33.45.3.67A8.21,8.21,0,0,0,24,8.25Z"></path><path d="M16.42,15.11A8.19,8.19,0,0,0,8.89,7.58c-.23,0-.45,0-.68,0a3.77,3.77,0,0,0-.67,0c0,.22,0,.45,0,.67a3.71,3.71,0,0,0,0,.67,8.26,8.26,0,0,0,7.57,7.5c.23,0,.45,0,.68,0a3.77,3.77,0,0,0,.67,0c0-.22,0-.45,0-.67S16.46,15.34,16.42,15.11ZM8.89,8.89a6.94,6.94,0,0,1,6.22,6.22A6.94,6.94,0,0,1,8.89,8.89Z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Simulador</span></div><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20.2 5.9l.8-.8C19.6 3.7 17.8 3 16 3s-3.6.7-5 2.1l.8.8C13 4.8 14.5 4.2 16 4.2s3 .6 4.2 1.7zm-.9.8c-.9-.9-2.1-1.4-3.3-1.4s-2.4.5-3.3 1.4l.8.8c.7-.7 1.6-1 2.5-1 .9 0 1.8.3 2.5 1l.8-.8zM19 13h-2V9h-2v4H5c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2zM8 18H6v-2h2v2zm3.5 0h-2v-2h2v2zm3.5 0h-2v-2h2v2z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Teste de Internet</span></div><span class="jss427"></span></div></ul></div></div></div></div><div class="jss399"></div><div id="inner" class="jss348" style="width: calc(100% - 210px);"><main class="jss347"><div class="jss346"></div><div style="height: 40px;"></div><div class="jss575 jss577"><div class="jss576"><div class="jss578"><div class="jss580"><svg class="jss420 jss583" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"></path><path fill="none" d="M0 0h24v24H0z"></path><path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"></path></svg><p class="jss448 jss457 jss584">11/10/18 15:32:07</p></div><div class="jss582"><svg class="jss420 jss583" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><p class="jss448 jss457 jss584">Pamela Aparecida Gomes | Vendedor* Agente Autorizado</p></div><div class="jss581"><svg class="jss420 jss583" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"></path></svg><p class="jss448 jss457 jss584">paaparecidagomes@gmail.com</p></div></div><div class="jss579"><p class="jss448 jss457 jss584 jss587 jss585" title="EDICLEIA MOTTA PEREIRA"><span>Ag. Autorizado:</span> 24.192.830/0001-26</p></div></div></div><header class="jss610 jss611"><div><h2 class="jss448 jss454 jss468 jss612 jss464 jss613">Vendas</h2><h3 class="jss448 jss455 jss614 jss468 jss464">DETALHES DA VENDA</h3></div></header><div class="container"><div class="row"><div class="col"><div class="jss365 jss621 jss370 jss366 jss625 jss620"><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Tipo de Contato</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">RECEPTIVO</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Venda Presencial?</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">NÃO</p></div></div></div></div><div class="jss365 jss368 jss1017"><div tabindex="0" class="jss417 jss1020 jss993" role="button" aria-expanded="false"><div class="jss1024"><p class="jss448 jss457">Produto</p></div><div tabindex="-1" class="jss417 jss411 jss1025" role="button" aria-hidden="true"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></div></div><div class="jss571" style="min-height: 0px; height: 0px; transition-duration: 346ms;" aria-hidden="true"><div class="jss573"><div class="jss574"><div class="jss1026 jss992"><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Tipo da Venda</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PROSPECT</p></div></div></div><div class="col-sm-12"><div class="row"><div class="col-sm-12"><div class="jss1027"><div style="margin-top: 16px;"><div class="jss1030"><aside class="jss448 jss456"><img src="/static/media/produto-internet.4afec6bc.svg" width="24" height="24" class="jss1035" alt="product-type">120 MEGA</aside><aside class="jss448 jss456">R$ 104,00</aside></div></div><div style="margin-top: 0px; margin-left: 32px;"><div class="jss1032"><span class="jss448 jss458">VALOR FORA DA PROMOÇÃO</span><span class="jss448 jss458">R$ 179,99</span></div></div><div class="jss1034"><p class="jss448 jss457">VELOCIDADE</p><div class="jss1032"><span class="jss448 jss458">DOWNLOAD</span><span class="jss448 jss458">120MB</span></div><div class="jss1032"><span class="jss448 jss458">UPLOAD</span><span class="jss448 jss458">10MB</span></div><div class="jss1032"><span class="jss448 jss458">FRANQUIA DE CONSUMO</span><span class="jss448 jss458">200GB</span></div></div><div class="jss1034"><p class="jss448 jss457">OFERTAS</p><div class="jss1032"><span class="jss448 jss458">POR R$ 99,00 POR 12 MESES (OFERTA MASSIVA)</span></div></div></div></div></div><div class="jss1028"><aside class="jss448 jss456"> DO 1º AO 12º MÊS R$ 104,00 | DO 13º MÊS EM DIANTE R$ 179,99 </aside></div><span class="jss448 jss458 jss1036"><div class="jss1032"><span>QUANTIDADE DE PARCELAS</span><span variant="caption">1</span></div></span><span class="jss448 jss458 jss1036">* FIDELIDADE DE 12 MESES</span></div></div></div></div></div></div></div><div class="jss365 jss368 jss1017"><div tabindex="0" class="jss417 jss1020 jss993" role="button" aria-expanded="false"><div class="jss1024"><p class="jss448 jss457">Cliente</p></div><div tabindex="-1" class="jss417 jss411 jss1025" role="button" aria-hidden="true"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></div></div><div class="jss571" style="min-height: 0px; height: 0px; transition-duration: 389ms;" aria-hidden="true"><div class="jss573"><div class="jss574"><div class="jss1026 jss992"><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Condomínio</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">NÃO</p></div></div></div></div><div class="row"></div><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Código</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">RESIDENCIAL</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Nome</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">HENRIQUE TOKUMITSU</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">CPF</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">120.030.876-05</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">RG/RNE</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">425589634</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Orgão Expedidor</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">SSP-SP</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Estado Civil</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">CASADO</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Sexo</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">MASCULINO</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Data de Nascimento</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">06/04/1993</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Escolaridade</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">ENSINO SUPERIOR</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Nome da Mãe</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">IVONE</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Nome do Pai</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">WESLEY</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Profissão</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">OUTROS</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">E-mail</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">NAOTEM464@BOL.COM.BR</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Telefone Residencial / Celular</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">(11) 9563-3456</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Telefone Celular</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">(11) 96596-3346</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Mídia</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">SEM MIDIA</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Como nos conheceu?</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">VENDAS PESSOAIS</p></div></div></div></div><aside class="jss448 jss456 jss441 jss443">Endereço de Instalação<span class="jss650 jss439"></span></aside><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">CEP</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">05763-450</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Logradouro</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R N S D B C</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Número</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">200</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Complemento</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">APT 05</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Bairro</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">CHACARA NOSSA SENHORA DO BOM CONSELHO</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Estado</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">SAO PAULO</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Cidade</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">SAO PAULO</p></div></div></div></div><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Endereço de cobrança</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">O ENDEREÇO DE COBRANÇA É IGUAL AO DE CADASTRO</p></div></div></div></div></div></div></div></div></div><div class="jss365 jss368 jss1017"><div tabindex="0" class="jss417 jss1020 jss993" role="button" aria-expanded="false"><div class="jss1024"><p class="jss448 jss457">Pagamento</p></div><div tabindex="-1" class="jss417 jss411 jss1025" role="button" aria-hidden="true"><span class="jss416"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss427"></span></div></div><div class="jss571" style="min-height: 0px; height: 0px; transition-duration: 337ms;" aria-hidden="true"><div class="jss573"><div class="jss574"><div class="jss1026 jss992"><div class="row"><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Valor Total</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R$ 179,99</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Valor promocional total</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R$ 104,00</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Valor da multa</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R$ 300,00</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Dia do Vencimento</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">15</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Forma de Pagamento</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">BOLETO</p></div></div></div></div><div class="row"><div class="col-sm-12"><aside class="jss448 jss456 jss441 jss443">Adesão<span class="jss650 jss439"></span></aside></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Valor Total</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R$ 0,00</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Nº de Parcela(s)</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">1</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Valor da Parcela</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">R$ 0,00</p></div></div></div></div><div class="row"><div class="col-sm-12"><aside class="jss448 jss456 jss441 jss443">Agendamento da Instalação<span class="jss650 jss439"></span></aside></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Data prevista da Instalação</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">08/10/2018</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Período</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">MANHA</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Data prevista da Instalação</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">09/10/2018</p></div></div></div><div class="col-sm-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Período</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">MANHA</p></div></div></div></div></div></div></div></div></div></div><div class="jss365 jss621 jss370 jss366 jss625 jss620"><div class="row"><div class="col-sm-12"><h2 class="jss448 jss454 jss441 jss443">Arquivos<span class="jss650 jss439"></span></h2></div></div><div class="row"><div class="col-md-4"><div class="jss1001 jss1003 jss1004"><div class="jss1001 jss1004"><div class="jss1043"><label class="jss1010 jss1005 jss1006 jss1009 jss1008" data-shrink="true" for="tipoArquivo">Tipo do arquivo</label><div class="Select is-clearable is-searchable Select--single"><div class="Select-control"><div class="Select-multi-value-wrapper" id="react-select-9--value"><div class="Select-placeholder">Selecione</div><div class="Select-input" style="display: inline-block;"><input id="input-tipoArquivo" autocomplete="new-tipoArquivo-1539282629539" aria-activedescendant="react-select-9--value" aria-expanded="false" aria-haspopup="false" aria-owns="" role="combobox" value="" style="box-sizing: content-box; width: 5px;"><div style="position: absolute; top: 0px; left: 0px; visibility: hidden; height: 0px; overflow: scroll; white-space: pre; font-size: 14px; font-family: Roboto, Helvetica, Arial, sans-serif; font-weight: 400; font-style: normal; letter-spacing: normal; text-transform: none;"></div></div></div><span class="Select-arrow-zone"><svg class="jss420" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10l5 5 5-5z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span></div></div></div></div></div></div><div class="col-sm-12"></div></div></div><div class="jss365 jss621 jss370 jss366 jss625 jss620"><div class="row"><div class="col"><div class=""><div class="jss1046"><div class="jss1049"><div><div style="width: 100px; height: 100px; position: absolute; top: -10000px; overflow: scroll;"></div></div><div class="jss1050"><div class="jss1052 jss1054" role="tablist" style="margin-bottom: -17px;"><div class="jss1050"><button tabindex="0" class="jss417 jss1058 jss1061 jss1063" type="button" role="tab" aria-selected="true"><span class="jss1066"><span class="jss1067"><span class="jss1068">Histórico de Interação</span></span></span><span class="jss427"></span></button><button tabindex="0" class="jss417 jss1058 jss1061" type="button" role="tab" aria-selected="false"><span class="jss1066"><span class="jss1067"><span class="jss1068">Confirmação Agendamento</span></span></span><span class="jss427"></span></button><button tabindex="0" class="jss417 jss1058 jss1061" type="button" role="tab" aria-selected="false"><span class="jss1066"><span class="jss1067"><span class="jss1068">Net Sales</span></span></span><span class="jss427"></span></button></div><span class="jss1070 jss1071 jss1057" style="left: 0px; width: 208px;"></span></div></div></div></div></div><div class="jss1073"><div class="row"><div class="col-sm-12"><div class="jss1345"><div class="jss1350"><span class="jss1348"><span class="jss1353">ARQUIVADA</span></span><span class="jss1348"><p class="jss448 jss457">04/10/2018 15:36:04</p></span><span class="jss1348"><div class="jss1346"></div></span><span class="jss1348"><div class="jss365 jss622 jss370 jss366 jss620 jss1351"><div class="row"><div class="col-md-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Usuário</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PAMELA APARECIDA GOMES</p></div></div></div></div><div class="jss1349"><div role="button" class="jss1370 jss1355 jss1357 jss1366" tabindex="-1"><span class="jss1386 jss1362">ARQUIVADA</span></div></div></div></span><span class="jss1348"></span></div><div class="jss1350"><span class="jss1348"><span class="jss1353">ARQUIVADA</span></span><span class="jss1348"><p class="jss448 jss457">04/10/2018 15:35:24</p></span><span class="jss1348"><div class="jss1346"></div></span><span class="jss1348"><div class="jss365 jss622 jss370 jss366 jss620 jss1351"><div class="row"><div class="col-md-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Usuário</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PAMELA APARECIDA GOMES</p></div></div></div></div><div class="jss1349"><div role="button" class="jss1370 jss1355 jss1357 jss1366" tabindex="-1"><span class="jss1386 jss1362">ARQUIVADA</span></div></div></div></span><span class="jss1348"></span></div><div class="jss1350"><span class="jss1348"><span class="jss1353">ARQUIVADA</span></span><span class="jss1348"><p class="jss448 jss457">04/10/2018 15:32:47</p></span><span class="jss1348"><div class="jss1346"></div></span><span class="jss1348"><div class="jss365 jss622 jss370 jss366 jss620 jss1351"><div class="row"><div class="col-md-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Usuário</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PAMELA APARECIDA GOMES</p></div></div></div></div><div class="jss1349"><div role="button" class="jss1370 jss1355 jss1357 jss1366" tabindex="-1"><span class="jss1386 jss1362">ARQUIVADA</span></div></div></div></span><span class="jss1348"></span></div><div class="jss1350"><span class="jss1348"><span class="jss1353">DEVOLVIDA</span></span><span class="jss1348"><p class="jss448 jss457">04/10/2018 15:32:22</p></span><span class="jss1348"><div class="jss1346"></div></span><span class="jss1348"><div class="jss365 jss622 jss370 jss366 jss620 jss1351"><div class="row"><div class="col-md-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Usuário</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PAMELA APARECIDA GOMES</p></div></div></div></div><div class="jss1349"><div role="button" class="jss1370 jss1355 jss1357 jss1366" tabindex="-1"><span class="jss1386 jss1362">DESISTENCIA DA ASSINATURA</span></div></div></div></span><span class="jss1348"></span></div><div class="jss1350"><span class="jss1348"><span class="jss1353">PROPOSTA</span></span><span class="jss1348"><p class="jss448 jss457">04/10/2018 15:31:37</p></span><span class="jss1348"><div class="jss1346"></div></span><span class="jss1348"><div class="jss365 jss622 jss370 jss366 jss620 jss1351"><div class="row"><div class="col-md-6 col-lg-4 col-xl-3"><div class="jss1001 jss1003 jss1004"><label class="jss1010 jss1005 jss1006 jss1009 jss1008 jss1007" data-shrink="true">Usuário</label><div class="jss994 jss996"><p class="jss448 jss457 jss998">PAMELA APARECIDA GOMES</p></div></div></div></div><div class="jss1349"><div role="button" class="jss1370 jss1355 jss1357 jss1366" tabindex="-1"><span class="jss1386 jss1362">AGUARDANDO TRATAMENTO</span></div></div></div></span><span class="jss1348"></span></div></div></div></div></div></div></div></div><div class="jss365 jss621 jss370 jss366 jss625 jss620"><div class="jss1121 jss1125 jss1124"><button tabindex="0" class="jss417 jss1132 jss1129 jss1134 jss1136 jss1137 jss1139" type="button"><span class="jss1133">Voltar</span><span class="jss427"></span></button></div></div></div></div></div></main><hr class="jss650 jss649"><footer class="jss645"><div class="container"><div class="row"><div class="col"><div class="jss646"><div class="d-flex align-items-center"><div class="jss647"><p class="jss448 jss457">Copyright ® 2018. v1.9.8</p><p class="jss448 jss457">Todos os direitos reservados.</p></div></div><img class="jss648" src="/static/media/logo-net-claro-embratel.dc3bdfa6.png" width="143" height="44" alt=""></div></div></div></div></footer></div></div></div><script type="text/javascript" src="main.c6506a63.js"></script><div class="jss479 jss503 jss480"><div class="jss654" aria-hidden="true" style="opacity: 0; will-change: opacity;"></div><div class="jss365 jss383 jss494 jss486 jss495" direction="right" role="document" tabindex="-1" style="transform: translateX(-234px);"><header class="jss489"><a class="jss349" href="/"><img src="/static/media/vendas-logo-outline.7bf3fae0.svg" width="32" height="32" alt="Conexão Vendas"><div class="jss350"><p class="jss448 jss457 jss467 jss352">conexão</p><p class="jss448 jss457 jss467 jss351">Vendas</p></div></a></header><div class="jss487"><ul class="jss519 jss520 jss504"><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Venda</span></div><svg class="jss420 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><defs><path id="a" d="M0 0h24v24H0V0z"></path></defs><path d="M14 10H2v2h12v-2zm0-4H2v2h12V6zM2 16h8v-2H2v2zm19.5-4.5L23 13l-6.99 7-4.51-4.5L13 14l3.01 3 5.49-5.5z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Viabilidade</span></div><svg class="jss420 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.11,16.42A6.9,6.9,0,1,1,7.58,8.89c0-.23.3-.41.3-.64s-.34-.45-.3-.67a8.22,8.22,0,1,0,8.88,8.84c-.22,0-.45-.3-.67-.3S15.34,16.46,15.11,16.42Z"></path><path d="M24,8.25A8.24,8.24,0,0,0,7.54,7.58c.22,0,.45.3.67.3s.41-.34.64-.3a6.92,6.92,0,0,1,13.8.67,6.91,6.91,0,0,1-6.22,6.86c0,.23-.3.41-.3.64s.33.45.3.67A8.21,8.21,0,0,0,24,8.25Z"></path><path d="M16.42,15.11A8.19,8.19,0,0,0,8.89,7.58c-.23,0-.45,0-.68,0a3.77,3.77,0,0,0-.67,0c0,.22,0,.45,0,.67a3.71,3.71,0,0,0,0,.67,8.26,8.26,0,0,0,7.57,7.5c.23,0,.45,0,.68,0a3.77,3.77,0,0,0,.67,0c0-.22,0-.45,0-.67S16.46,15.34,16.42,15.11ZM8.89,8.89a6.94,6.94,0,0,1,6.22,6.22A6.94,6.94,0,0,1,8.89,8.89Z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Simulador</span></div><span class="jss427"></span></div><div tabindex="0" class="jss417 jss553 jss551 jss556 jss560 jss550 jss561" role="button"><svg class="jss420 jss564 jss540 jss540" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20.2 5.9l.8-.8C19.6 3.7 17.8 3 16 3s-3.6.7-5 2.1l.8.8C13 4.8 14.5 4.2 16 4.2s3 .6 4.2 1.7zm-.9.8c-.9-.9-2.1-1.4-3.3-1.4s-2.4.5-3.3 1.4l.8.8c.7-.7 1.6-1 2.5-1 .9 0 1.8.3 2.5 1l.8-.8zM19 13h-2V9h-2v4H5c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2zM8 18H6v-2h2v2zm3.5 0h-2v-2h2v2zm3.5 0h-2v-2h2v2z"></path></svg><div class="jss565 jss546 jss566"><span class="jss448 jss455 jss568 jss542 jss543">Teste de Internet</span></div><span class="jss427"></span></div></ul></div></div></div><span id="recharts_measurement_span" style="position: absolute; top: -20000px; left: 0px; padding: 0px; margin: 0px; border: none; white-space: pre;">08:00</span></body></html>