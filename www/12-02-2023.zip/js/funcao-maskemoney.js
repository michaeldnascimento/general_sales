$(function(){
   $("#valor").maskMoney({prefix:'R$ ', thousands:'.',decimal:','});
});