<html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="shortcut icon" href="/favicon.png"><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500"><title>Vendas</title><link href="main.be77eb79.css" rel="stylesheet">
<style data-jss="" data-meta="MuiTypography">
.jss466 {
  margin: 0;
  display: block;
}
.jss467 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 7rem;
  font-weight: 300;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.14286em;
  margin-left: -.04em;
  letter-spacing: -.04em;
}
.jss468 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 3.5rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.30357em;
  margin-left: -.02em;
  letter-spacing: -.02em;
}
.jss469 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 2.8125rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.13333em;
  margin-left: -.02em;
}
.jss470 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 2.125rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.20588em;
}
.jss471 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1.5rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.35417em;
}
.jss472 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1.3125rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.16667em;
}
.jss473 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 1rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.5em;
}
.jss474 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.71429em;
}
.jss475 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.46429em;
}
.jss476 {
  color: rgba(69, 90, 100, 0.54);
  font-size: 0.75rem;
  font-weight: 400;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.375em;
}
.jss477 {
  color: rgba(69, 90, 100, 0.87);
  font-size: 0.875rem;
  font-weight: 500;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  text-transform: uppercase;
}
.jss478 {
  text-align: left;
}
.jss479 {
  text-align: center;
}
.jss480 {
  text-align: right;
}
.jss481 {
  text-align: justify;
}
.jss482 {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.jss483 {
  margin-bottom: 0.35em;
}
.jss484 {
  margin-bottom: 16px;
}
.jss485 {
  color: inherit;
}
.jss486 {
  color: #4caf50;
}
.jss487 {
  color: #ab47bc;
}
.jss488 {
  color: rgba(69, 90, 100, 0.87);
}
.jss489 {
  color: rgba(69, 90, 100, 0.54);
}
.jss490 {
  color: #f44336;
}
</style><style data-jss="" data-meta="MuiTouchRipple">
.jss445 {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: block;
  z-index: 0;
  position: absolute;
  overflow: hidden;
  border-radius: inherit;
  pointer-events: none;
}
.jss446 {
  top: 0;
  left: 0;
  width: 50px;
  height: 50px;
  opacity: 0;
  position: absolute;
}
.jss447 {
  opacity: 0.3;
  transform: scale(1);
  animation: mui-ripple-enter 550ms cubic-bezier(0.4, 0, 0.2, 1);
}
.jss448 {
  animation-duration: 200ms;
}
.jss449 {
  width: 100%;
  height: 100%;
  opacity: 1;
  display: block;
  border-radius: 50%;
  background-color: currentColor;
}
.jss450 {
  opacity: 0;
  animation: mui-ripple-exit 550ms cubic-bezier(0.4, 0, 0.2, 1);
}
.jss451 {
  top: 0;
  left: 0;
  position: absolute;
  animation: mui-ripple-pulsate 2500ms cubic-bezier(0.4, 0, 0.2, 1) 200ms infinite;
}
@-webkit-keyframes mui-ripple-enter {
  0% {
    opacity: 0.1;
    transform: scale(0);
  }
  100% {
    opacity: 0.3;
    transform: scale(1);
  }
}
@-webkit-keyframes mui-ripple-exit {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@-webkit-keyframes mui-ripple-pulsate {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(0.92);
  }
  100% {
    transform: scale(1);
  }
}
</style><style data-jss="" data-meta="MuiButtonBase">
.jss435 {
  color: inherit;
  cursor: pointer;
  margin: 0;
  border: 0;
  display: inline-flex;
  padding: 0;
  outline: none;
  position: relative;
  user-select: none;
  align-items: center;
  border-radius: 0;
  vertical-align: middle;
  justify-content: center;
  -moz-appearance: none;
  text-decoration: none;
  background-color: transparent;
  -webkit-appearance: none;
  -webkit-tap-highlight-color: transparent;
}
.jss435::-moz-focus-inner {
  border-style: none;
}
.jss435.jss436 {
  cursor: default;
  pointer-events: none;
}
</style><style data-jss="" data-meta="MuiIconButton">
.jss429 {
  flex: 0 0 auto;
  width: 48px;
  color: rgba(69, 90, 100, 0.54);
  height: 48px;
  padding: 0;
  overflow: visible;
  font-size: 1.5rem;
  text-align: center;
  transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  border-radius: 50%;
}
.jss429:hover {
  background-color: rgba(69, 90, 100, 0.08);
}
.jss429.jss433 {
  color: rgba(69, 90, 100, 0.26);
}
@media (hover: none) {
  .jss429:hover {
    background-color: transparent;
  }
}
.jss429:hover.jss433 {
  background-color: transparent;
}
.jss430 {
  color: inherit;
}
.jss431 {
  color: #4caf50;
}
.jss431:hover {
  background-color: rgba(76, 175, 80, 0.08);
}
@media (hover: none) {
  .jss431:hover {
    background-color: transparent;
  }
}
.jss432 {
  color: #ab47bc;
}
.jss432:hover {
  background-color: rgba(171, 71, 188, 0.08);
}
@media (hover: none) {
  .jss432:hover {
    background-color: transparent;
  }
}
.jss434 {
  width: 100%;
  display: flex;
  align-items: inherit;
  justify-content: inherit;
}
</style><style data-jss="" data-meta="MuiListItem">
.jss571 {
  width: 100%;
  display: flex;
  position: relative;
  box-sizing: border-box;
  text-align: left;
  align-items: center;
  padding-top: 12px;
  padding-bottom: 12px;
  justify-content: flex-start;
  text-decoration: none;
}
.jss571.jss581 {
  background-color: rgba(69, 90, 100, 0.08);
}
.jss572 {
  position: relative;
}
.jss573 {
  background-color: rgba(69, 90, 100, 0.14);
}
.jss575 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.jss576 {
  opacity: 0.5;
}
.jss577 {
  border-bottom: 1px solid rgba(69, 90, 100, 0.12);
  background-clip: padding-box;
}
.jss578 {
  padding-left: 16px;
  padding-right: 16px;
}
@media (min-width:576px) {
  .jss578 {
    padding-left: 24px;
    padding-right: 24px;
  }
}
.jss579 {
  transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss579:hover {
  text-decoration: none;
  background-color: rgba(69, 90, 100, 0.14);
}
@media (hover: none) {
  .jss579:hover {
    background-color: transparent;
  }
}
.jss580 {
  padding-right: 32px;
}
</style><style data-jss="" data-meta="MuiTooltip">
.jss606 {
  z-index: 1500;
  opacity: 0.9;
}
.jss607 {
  color: #fff;
  padding: 4px 8px;
  font-size: 0.625rem;
  max-width: 300px;
  font-family: "Roboto", "Helvetica", "Arial", sans-serif;
  line-height: 1.4em;
  border-radius: 4px;
  background-color: #455a64;
}
.jss608 {
  padding: 8px 16px;
  font-size: 0.875rem;
  line-height: 1.14286em;
}
.jss609 {
  margin: 0 24px ;
  transform-origin: right center;
}
@media (min-width:576px) {
  .jss609 {
    margin: 0 14px;
  }
}
.jss610 {
  margin: 0 24px;
  transform-origin: left center;
}
@media (min-width:576px) {
  .jss610 {
    margin: 0 14px;
  }
}
.jss611 {
  margin: 24px 0;
  transform-origin: center bottom;
}
@media (min-width:576px) {
  .jss611 {
    margin: 14px 0;
  }
}
.jss612 {
  margin: 24px 0;
  transform-origin: center top;
}
@media (min-width:576px) {
  .jss612 {
    margin: 14px 0;
  }
}
</style><style data-jss="">
@media (min-width:0px) and (max-width:575.95px) {
  .jss410 {
    display: none;
  }
}
@media (min-width:0px) {
  .jss411 {
    display: none;
  }
}
@media (max-width:575.95px) {
  .jss412 {
    display: none;
  }
}
@media (min-width:576px) and (max-width:767.95px) {
  .jss413 {
    display: none;
  }
}
@media (min-width:576px) {
  .jss414 {
    display: none;
  }
}
@media (max-width:767.95px) {
  .jss415 {
    display: none;
  }
}
@media (min-width:768px) and (max-width:991.95px) {
  .jss416 {
    display: none;
  }
}
@media (min-width:768px) {
  .jss417 {
    display: none;
  }
}
@media (max-width:991.95px) {
  .jss418 {
    display: none;
  }
}
@media (min-width:992px) and (max-width:1199.95px) {
  .jss419 {
    display: none;
  }
}
@media (min-width:992px) {
  .jss420 {
    display: none;
  }
}
@media (max-width:1199.95px) {
  .jss421 {
    display: none;
  }
}
@media (min-width:1200px) {
  .jss422 {
    display: none;
  }
}
@media (min-width:1200px) {
  .jss423 {
    display: none;
  }
}
@media (min-width:0px) {
  .jss424 {
    display: none;
  }
}
</style><style data-jss="" data-meta="MuiList">
.jss537 {
  margin: 0;
  padding: 0;
  position: relative;
  list-style: none;
}
.jss538 {
  padding-top: 8px;
  padding-bottom: 8px;
}
.jss539 {
  padding-top: 4px;
  padding-bottom: 4px;
}
.jss540 {
  padding-top: 0;
}
</style><style data-jss="" data-meta="MuiListItemText">
.jss583 {
  flex: 1 1 auto;
  padding: 0 16px;
  min-width: 0;
}
.jss583:first-child {
  padding-left: 0;
}
.jss584:first-child {
  padding-left: 56px;
}
.jss585 {
  font-size: 0.8125rem;
}
.jss586.jss588 {
  font-size: inherit;
}
.jss587.jss588 {
  font-size: inherit;
}
</style><style data-jss="" data-meta="MuiBackdrop">
.jss670 {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: -1;
  position: fixed;
  touch-action: none;
  background-color: rgba(0, 0, 0, 0.5);
  -webkit-tap-highlight-color: transparent;
}
.jss671 {
  background-color: transparent;
}
</style><style data-jss="" data-meta="MuiModal">
.jss497 {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1300;
  position: fixed;
}
.jss498 {
  visibility: hidden;
}
</style><style data-jss="" data-meta="MuiPaper">
.jss383 {
  background-color: #fff;
}
.jss384 {
  border-radius: 4px;
}
.jss385 {
  box-shadow: none;
}
.jss386 {
  box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.1),0px 1px 1px 0px rgba(0, 0, 0, 0.01),0px 2px 1px -1px rgba(0, 0, 0, 0.01);
}
.jss387 {
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.1),0px 2px 2px 0px rgba(0, 0, 0, 0.01),0px 3px 1px -2px rgba(0, 0, 0, 0.01);
}
.jss388 {
  box-shadow: 0px 1px 8px 0px rgba(0, 0, 0, 0.1),0px 3px 4px 0px rgba(0, 0, 0, 0.01),0px 3px 3px -2px rgba(0, 0, 0, 0.01);
}
.jss389 {
  box-shadow: 0px 2px 4px -1px rgba(0, 0, 0, 0.1),0px 4px 5px 0px rgba(0, 0, 0, 0.01),0px 1px 10px 0px rgba(0, 0, 0, 0.01);
}
.jss390 {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 5px 8px 0px rgba(0, 0, 0, 0.01),0px 1px 14px 0px rgba(0, 0, 0, 0.01);
}
.jss391 {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.1),0px 6px 10px 0px rgba(0, 0, 0, 0.01),0px 1px 18px 0px rgba(0, 0, 0, 0.01);
}
.jss392 {
  box-shadow: 0px 4px 5px -2px rgba(0, 0, 0, 0.1),0px 7px 10px 1px rgba(0, 0, 0, 0.01),0px 2px 16px 1px rgba(0, 0, 0, 0.01);
}
.jss393 {
  box-shadow: 0px 5px 5px -3px rgba(0, 0, 0, 0.1),0px 8px 10px 1px rgba(0, 0, 0, 0.01),0px 3px 14px 2px rgba(0, 0, 0, 0.01);
}
.jss394 {
  box-shadow: 0px 5px 6px -3px rgba(0, 0, 0, 0.1),0px 9px 12px 1px rgba(0, 0, 0, 0.01),0px 3px 16px 2px rgba(0, 0, 0, 0.01);
}
.jss395 {
  box-shadow: 0px 6px 6px -3px rgba(0, 0, 0, 0.1),0px 10px 14px 1px rgba(0, 0, 0, 0.01),0px 4px 18px 3px rgba(0, 0, 0, 0.01);
}
.jss396 {
  box-shadow: 0px 6px 7px -4px rgba(0, 0, 0, 0.1),0px 11px 15px 1px rgba(0, 0, 0, 0.01),0px 4px 20px 3px rgba(0, 0, 0, 0.01);
}
.jss397 {
  box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.1),0px 12px 17px 2px rgba(0, 0, 0, 0.01),0px 5px 22px 4px rgba(0, 0, 0, 0.01);
}
.jss398 {
  box-shadow: 0px 7px 8px -4px rgba(0, 0, 0, 0.1),0px 13px 19px 2px rgba(0, 0, 0, 0.01),0px 5px 24px 4px rgba(0, 0, 0, 0.01);
}
.jss399 {
  box-shadow: 0px 7px 9px -4px rgba(0, 0, 0, 0.1),0px 14px 21px 2px rgba(0, 0, 0, 0.01),0px 5px 26px 4px rgba(0, 0, 0, 0.01);
}
.jss400 {
  box-shadow: 0px 8px 9px -5px rgba(0, 0, 0, 0.1),0px 15px 22px 2px rgba(0, 0, 0, 0.01),0px 6px 28px 5px rgba(0, 0, 0, 0.01);
}
.jss401 {
  box-shadow: 0px 8px 10px -5px rgba(0, 0, 0, 0.1),0px 16px 24px 2px rgba(0, 0, 0, 0.01),0px 6px 30px 5px rgba(0, 0, 0, 0.01);
}
.jss402 {
  box-shadow: 0px 8px 11px -5px rgba(0, 0, 0, 0.1),0px 17px 26px 2px rgba(0, 0, 0, 0.01),0px 6px 32px 5px rgba(0, 0, 0, 0.01);
}
.jss403 {
  box-shadow: 0px 9px 11px -5px rgba(0, 0, 0, 0.1),0px 18px 28px 2px rgba(0, 0, 0, 0.01),0px 7px 34px 6px rgba(0, 0, 0, 0.01);
}
.jss404 {
  box-shadow: 0px 9px 12px -6px rgba(0, 0, 0, 0.1),0px 19px 29px 2px rgba(0, 0, 0, 0.01),0px 7px 36px 6px rgba(0, 0, 0, 0.01);
}
.jss405 {
  box-shadow: 0px 10px 13px -6px rgba(0, 0, 0, 0.1),0px 20px 31px 3px rgba(0, 0, 0, 0.01),0px 8px 38px 7px rgba(0, 0, 0, 0.01);
}
.jss406 {
  box-shadow: 0px 10px 13px -6px rgba(0, 0, 0, 0.1),0px 21px 33px 3px rgba(0, 0, 0, 0.01),0px 8px 40px 7px rgba(0, 0, 0, 0.01);
}
.jss407 {
  box-shadow: 0px 10px 14px -6px rgba(0, 0, 0, 0.1),0px 22px 35px 3px rgba(0, 0, 0, 0.01),0px 8px 42px 7px rgba(0, 0, 0, 0.01);
}
.jss408 {
  box-shadow: 0px 11px 14px -7px rgba(0, 0, 0, 0.1),0px 23px 36px 3px rgba(0, 0, 0, 0.01),0px 9px 44px 8px rgba(0, 0, 0, 0.01);
}
.jss409 {
  box-shadow: 0px 11px 15px -7px rgba(0, 0, 0, 0.1),0px 24px 38px 3px rgba(0, 0, 0, 0.01),0px 9px 46px 8px rgba(0, 0, 0, 0.01);
}
</style><style data-jss="" data-meta="MuiPopover">
.jss496 {
  outline: none;
  position: absolute;
  min-width: 16px;
  max-width: calc(100% - 32px);
  overflow-y: auto;
  overflow-x: hidden;
  min-height: 16px;
  max-height: calc(100% - 32px);
}
</style><style data-jss="" data-meta="MuiMenu">
.jss2382 {
  max-height: calc(100% - 96px);
  -webkit-overflow-scrolling: touch;
}
</style><style data-jss="" data-meta="MuiSvgIcon">
.jss438 {
  fill: currentColor;
  width: 1em;
  height: 1em;
  display: inline-block;
  font-size: 24px;
  transition: fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  user-select: none;
  flex-shrink: 0;
}
.jss439 {
  color: #4caf50;
}
.jss440 {
  color: #ab47bc;
}
.jss441 {
  color: rgba(69, 90, 100, 0.54);
}
.jss442 {
  color: #f44336;
}
.jss443 {
  color: rgba(69, 90, 100, 0.26);
}
.jss444 {
  font-size: inherit;
}
</style><style data-jss="" data-meta="MuiDialog">
.jss617 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.jss618 {
  overflow-y: auto;
  overflow-x: hidden;
}
.jss619 {
  margin: 48px;
  display: flex;
  outline: none;
  position: relative;
  overflow-y: auto;
  flex-direction: column;
}
.jss620 {
  flex: 0 1 auto;
  max-height: calc(100% - 96px);
}
.jss621 {
  margin: 48px auto;
}
.jss622 {
  max-width: 360px;
}
@media (max-width:455.95px) {
  .jss622.jss621 {
    margin: 48px;
  }
}
.jss623 {
  max-width: 576px;
}
@media (max-width:671.95px) {
  .jss623.jss621 {
    margin: 48px;
  }
}
.jss624 {
  max-width: 768px;
}
@media (max-width:863.95px) {
  .jss624.jss621 {
    margin: 48px;
  }
}
.jss625 {
  max-width: 992px;
}
@media (max-width:1087.95px) {
  .jss625.jss621 {
    margin: 48px;
  }
}
.jss626 {
  width: 100%;
}
.jss627 {
  width: 100%;
  margin: 0;
  height: 100%;
  max-width: 100%;
  max-height: none;
  border-radius: 0;
}
.jss627.jss621 {
  margin: 0;
}
</style><style data-jss="" data-meta="MuiDivider">
.jss666 {
  height: 1px;
  margin: 0;
  border: none;
  flex-shrink: 0;
  background-color: rgba(69, 90, 100, 0.12);
}
.jss667 {
  left: 0;
  width: 100%;
  bottom: 0;
  position: absolute;
}
.jss668 {
  margin-left: 72px;
}
.jss669 {
  background-color: rgba(69, 90, 100, 0.08);
}
</style><style data-jss="" data-meta="MuiAppBar">
.jss375 {
  width: 100%;
  display: flex;
  z-index: 1100;
  box-sizing: border-box;
  flex-shrink: 0;
  flex-direction: column;
}
.jss376 {
  top: 0;
  left: auto;
  right: 0;
  position: fixed;
}
.jss377 {
  top: 0;
  left: auto;
  right: 0;
  position: absolute;
}
.jss378 {
  top: 0;
  left: auto;
  right: 0;
  position: sticky;
}
.jss379 {
  position: static;
}
.jss380 {
  color: rgba(0, 0, 0, 0.87);
  background-color: #cfd8dc;
}
.jss381 {
  color: #fff;
  background-color: #4caf50;
}
.jss382 {
  color: #fff;
  background-color: #ab47bc;
}
</style><style data-jss="" data-meta="MuiToolbar">
.jss425 {
  display: flex;
  position: relative;
  align-items: center;
}
.jss426 {
  padding-left: 16px;
  padding-right: 16px;
}
@media (min-width:576px) {
  .jss426 {
    padding-left: 24px;
    padding-right: 24px;
  }
}
.jss427 {
  min-height: 56px;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss427 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss427 {
    min-height: 64px;
  }
}
.jss428 {
  min-height: 48px;
}
</style><style data-jss="" data-meta="MuiDrawer">
.jss511 {
  flex: 0 0 auto;
}
.jss512 {
  top: 0;
  flex: 1 0 auto;
  height: 100%;
  display: flex;
  z-index: 1200;
  outline: none;
  position: fixed;
  overflow-y: auto;
  flex-direction: column;
  -webkit-overflow-scrolling: touch;
}
.jss513 {
  left: 0;
  right: auto;
}
.jss514 {
  left: auto;
  right: 0;
}
.jss515 {
  top: 0;
  left: 0;
  right: 0;
  bottom: auto;
  height: auto;
  max-height: 100%;
}
.jss516 {
  top: auto;
  left: 0;
  right: 0;
  bottom: 0;
  height: auto;
  max-height: 100%;
}
.jss517 {
  border-right: 1px solid rgba(69, 90, 100, 0.12);
}
.jss518 {
  border-bottom: 1px solid rgba(69, 90, 100, 0.12);
}
.jss519 {
  border-left: 1px solid rgba(69, 90, 100, 0.12);
}
.jss520 {
  border-top: 1px solid rgba(69, 90, 100, 0.12);
}
</style><style data-jss="" data-meta="MuiCollapse">
.jss589 {
  height: 0;
  overflow: hidden;
  transition: height 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
}
.jss590 {
  height: auto;
}
.jss591 {
  display: flex;
}
.jss592 {
  width: 100%;
}
</style><style data-jss="" data-meta="MuiListItemIcon">
.jss582 {
  color: rgba(69, 90, 100, 0.54);
  flex-shrink: 0;
  margin-right: 16px;
}
</style><style data-jss="" data-meta="XTypography">
.jss456 {
  display: inline;
}
.jss457 {
  display: block;
  margin-top: 8px;
}
.jss458 {
  margin-top: 8px !important;
}
.jss459 {
  margin-top: 16px !important;
}
.jss460 {
  margin-top: 24px !important;
}
.jss461 {
  margin-bottom: 8px !important;
}
.jss462 {
  margin-bottom: 16px !important;
}
.jss463 {
  margin-bottom: 24px !important;
}
.jss464 {
  cursor: pointer;
}
.jss465 {
  border: none;
  background: transparent;
}
</style><style data-jss="" data-meta="XPaper">
.jss633 {
  padding: 16px;
}
.jss634 {
  background-color: #fff;
}
.jss635 {
  background-color: #eceff1;
}
.jss636 {
  width: 100%;
}
.jss637 {
  margin-top: 8px !important;
}
.jss638 {
  margin-top: 16px !important;
}
.jss639 {
  margin-top: 24px !important;
}
.jss640 {
  margin-bottom: 8px !important;
}
.jss641 {
  margin-bottom: 16px !important;
}
.jss642 {
  margin-bottom: 24px !important;
}
</style><style data-jss="" data-meta="XDrawerAppBar">
.jss371 {
  background-color: #fff;
  border-bottom-color: rgba(232, 235, 236, 1);
  border-bottom-style: solid;
  border-bottom-width: 1px;
}
@media (min-width:768px) {
  .jss371 {
    width: calc(100% - 0px);
    z-index: 1201;
  }
}
@media (min-width:768px) {
  .jss372 {
    width: calc(100% - 210px);
    margin-left: 210px;
  }
}
@media (min-width:576px) {
  .jss373 {
    padding: 8px;
  }
}
.jss374 {
  margin: 0 4px 0 0;
}
@media (min-width:576px) {
  .jss374 {
    margin: 0 4px;
  }
}
</style><style data-jss="" data-meta="XDrawerMenuItem">
.jss556 {
  width: 100%;
}
.jss557 {
  padding-left: 8px;
}
.jss557:hover {
  background: rgb(23, 30, 33);
}
.jss558 {
  color: #cfd8dc;
}
.jss559 {
  color: #4caf50;
}
.jss560 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss561 {
  color: #cfd8dc;
}
.jss562 {
  color: #4caf50;
}
.jss563 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss564 {
  padding-left: 0;
}
.jss565:first-child {
  padding-left: 16px;
}
.jss566 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss567 {
  background: rgb(28, 37, 41);
}
.jss568 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss569 {
  border-left: 3px solid transparent;
}
.jss569:hover {
  background: rgb(42, 54, 61);
}
.jss570 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawerCallapseItem">
.jss541 {
  width: 100%;
}
.jss542 {
  padding-left: 8px;
}
.jss542:hover {
  background: rgb(23, 30, 33);
}
.jss543 {
  color: #cfd8dc;
}
.jss544 {
  color: #4caf50;
}
.jss545 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss546 {
  color: #cfd8dc;
}
.jss547 {
  color: #4caf50;
}
.jss548 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss549 {
  padding-left: 0;
}
.jss550:first-child {
  padding-left: 16px;
}
.jss551 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss552 {
  background: rgb(28, 37, 41);
}
.jss553 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss554 {
  border-left: 3px solid transparent;
}
.jss554:hover {
  background: rgb(42, 54, 61);
}
.jss555 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawerMenu">
.jss522 {
  width: 100%;
}
.jss523 {
  padding-left: 8px;
}
.jss523:hover {
  background: rgb(23, 30, 33);
}
.jss524 {
  color: #cfd8dc;
}
.jss525 {
  color: #4caf50;
}
.jss526 {
  font-size: 0.875rem;
  font-weight: 300;
}
.jss527 {
  color: #cfd8dc;
}
.jss528 {
  color: #4caf50;
}
.jss529 {
  color: #b0bec5;
  font-size: 0.8125rem;
  font-weight: 300;
}
.jss530 {
  padding-left: 0;
}
.jss531:first-child {
  padding-left: 16px;
}
.jss532 {
  background-color: rgba(255, 255, 255, 0.12);
}
.jss533 {
  background: rgb(28, 37, 41);
}
.jss534 {
  padding-left: 16px;
  padding-right: 16px;
}
.jss535 {
  border-left: 3px solid transparent;
}
.jss535:hover {
  background: rgb(42, 54, 61);
}
.jss536 {
  border-left: 3px solid #4caf50;
}
</style><style data-jss="" data-meta="XDrawer">
.jss504 {
  width: 210px;
  border: 0;
  background: rgb(48, 62, 69);
  overflow-x: hidden;
}
.jss505 {
  top: 56px;
  width: 210px;
  height: calc(100% - 56px);
  position: fixed;
  overflow-y: auto;
}
@media (min-width:576px) {
  .jss505 {
    top: 64px;
    height: calc(100% - 64px);
  }
}
@media (min-width:768px) {
  .jss505 {
    position: absolute;
  }
  .jss505::-webkit-scrollbar-track {
    box-shadow: none;
    background-color: transparent;
  }
  .jss505::-webkit-scrollbar {
    width: 8px;
  }
  .jss505::-webkit-scrollbar-thumb {
    box-shadow: none;
    border-radius: 0;
    background-color: rgb(81, 91, 95);
  }
}
.jss506 {
  width: 0;
}
.jss507 {
  color: #fff;
  display: flex;
  background: rgb(48, 62, 69);
  min-height: 56px;
  align-items: center;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss507 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss507 {
    min-height: 64px;
  }
}
.jss508 {
  width: 32px;
  height: 32px;
  margin: 0 12px;
}
.jss509 {
  width: 100%;
  cursor: pointer;
  border: 0;
  display: flex;
  min-height: 56px;
  align-items: center;
  padding-top: 0;
  padding-left: 0;
  padding-right: 0;
  padding-bottom: 0;
  background-color: transparent;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss509 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss509 {
    min-height: 64px;
  }
}
.jss509:hover {
  text-decoration: none;
}
.jss510 {
  color: #fff;
  font-size: 1.25rem;
}
</style><style data-jss="">
.jss614 {
  margin: 24px;
  max-width: 576px;
  max-height: 490px;
}
.jss615 {
  padding-left: 16px;
  padding-right: 16px;
}
</style><style data-jss="">
.jss613 {
  height: 32px;
  display: flex;
  background: #fff9c4;
  align-items: center;
  justify-content: center;
}
</style><style data-jss="">
.jss593 {
  top: 56px;
  width: 100%;
  z-index: 2;
  position: fixed;
  box-shadow: 0px 4px 8px -3px rgba(232, 235, 236, 1);
}
@media (min-width:0px) and (orientation: landscape) {
  .jss593 {
    top: 48px;
  }
}
@media (min-width:576px) {
  .jss593 {
    top: 64px;
  }
}
.jss594 {
  height: 40px;
  display: flex;
  background: #fff;
  align-items: center;
}
@media (min-width:768px) {
  .jss594 {
    padding-left: 8px;
  }
}
@media (min-width:576px) {
  .jss594 {
    justify-content: space-between;
  }
}
.jss595 {
  width: 100%;
}
@media (min-width:768px) {
  .jss595 {
    width: calc(100% - 210px);
  }
}
.jss596 {
  display: none;
}
@media (min-width:576px) {
  .jss596 {
    display: flex;
    align-items: center;
  }
}
.jss597 {
  display: flex;
  align-items: center;
}
@media (min-width:0px) and (max-width:575.95px) {
  .jss597 {
    flex: 1;
    padding-left: 8px;
    padding-right: 8px;
    justify-content: space-between;
  }
}
.jss598 {
  display: none;
}
@media (min-width:576px) {
  .jss598 {
    display: flex;
  }
}
.jss599 {
  display: none;
}
@media (min-width:992px) {
  .jss599 {
    display: flex;
  }
}
.jss600 {
  display: none;
}
@media (min-width:1200px) {
  .jss600 {
    display: flex;
  }
}
.jss601 {
  width: 16px;
  color: rgba(69, 90, 100, 0.54);
  height: 16px;
  margin-left: 8px;
  margin-right: 8px;
}
.jss602 {
  font-size: 0.75rem;
  font-weight: 300;
}
.jss602 span {
  font-weight: 400;
}
.jss603 {
  margin-right: 8px;
}
@media (min-width:576px) {
  .jss604 {
    margin-left: 8px;
    margin-right: 8px;
  }
}
.jss604:hover {
  background: transparent;
}
.jss605 {
  cursor: help;
}
</style><style data-jss="" data-meta="XPageHeader">
.jss628 {
  background: #fff;
  border-bottom-color: rgba(232, 235, 236, 1);
  border-bottom-style: solid;
  border-bottom-width: 1px;
}
.jss629 {
  margin-bottom: 8px;
}
@media (min-width:576px) {
  .jss629 {
    margin-bottom: 16px;
  }
}
@media (min-width:992px) {
  .jss629 {
    margin-bottom: 24px;
  }
}
.jss630 {
  color: rgba(69, 90, 100, 0.87);
}
.jss631 {
  height: 40px;
  display: flex;
  align-items: center;
  font-weight: 400;
  padding-top: 16px;
  padding-left: 16px;
}
@media (min-width:768px) {
  .jss631 {
    height: 48px;
  }
}
.jss632 {
  height: 48px;
  display: inline-flex;
  font-size: 0.75rem;
  align-items: center;
  font-weight: 500;
  padding-left: 16px;
  border-bottom: 2px solid #4caf50;
  padding-right: 16px;
}
@media (min-width:768px) {
  .jss632 {
    font-size: 0.8125rem;
  }
}
</style><style data-jss="" data-meta="MuiSnackbar">
.jss4 {
  left: 0;
  right: 0;
  z-index: 1400;
  display: flex;
  position: fixed;
  align-items: center;
  justify-content: center;
}
.jss5 {
  top: 0;
}
@media (min-width:768px) {
  .jss5 {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
  }
}
.jss6 {
  bottom: 0;
}
@media (min-width:768px) {
  .jss6 {
    left: 50%;
    right: auto;
    transform: translateX(-50%);
  }
}
.jss7 {
  top: 0;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss7 {
    top: 24px;
    left: auto;
    right: 24px;
  }
}
.jss8 {
  bottom: 0;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss8 {
    left: auto;
    right: 24px;
    bottom: 24px;
  }
}
.jss9 {
  top: 0;
  justify-content: flex-start;
}
@media (min-width:768px) {
  .jss9 {
    top: 24px;
    left: 24px;
    right: auto;
  }
}
.jss10 {
  bottom: 0;
  justify-content: flex-start;
}
@media (min-width:768px) {
  .jss10 {
    left: 24px;
    right: auto;
    bottom: 24px;
  }
}
</style><style data-jss="">
.jss1 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style><style data-jss="">
.jss2393 {
  width: 100%;
  margin: 16px;
  max-width: 992px;
}
.jss2394, .jss2394:first-child {
  padding: 0;
}
</style><style data-jss="">
.jss2383 {
  display: flex;
  background: #fff;
  align-items: center;
  padding-top: 16px;
  padding-bottom: 16px;
  justify-content: center;
}
.jss2384 {
  color: #607d8b;
  font-size: 1.875rem;
  min-width: 75px;
  font-weight: 500;
  margin-right: 16px;
}
.jss2385 {
  color: #78909c;
  min-width: 100px;
  margin-left: 16px;
}
</style><style data-jss="">
.jss2375 {
  display: flex;
  justify-content: space-between;
}
.jss2376 {
  display: inline-block;
  position: relative;
  margin-bottom: 24px;
  padding-bottom: 16px;
}
.jss2376:after {
  left: 0;
  width: 40px;
  bottom: 0;
  height: 2px;
  content: "";
  position: absolute;
  background: #4caf50;
}
.jss2377 {
  margin-left: 8px;
}
.jss2378 {
  padding: 8px;
  max-width: 300px;
}
.jss2379 {
  top: -10px;
  position: absolute;
}
.jss2380 {
  width: 36px;
  height: 36px;
}
.jss2380:hover {
  color: #607d8b;
  background: none;
}
.jss2381 {
  margin-right: -8px;
}
</style><style data-jss="">
.jss2390 {
  text-align: center;
  margin-top: 12px;
  margin-bottom: 12px;
}
.jss2391 {
  color: #607d8b;
  font-size: 0.875rem;
  font-weight: 300;
}
.jss2391:last-child > span {
  margin-right: 0;
}
.jss2392 {
  margin-right: 8px;
}
</style><style data-jss="">
.jss2389 {
  display: flex;
  align-items: center;
  justify-content: center;
}
.pie-lined .recharts-legend-item-text {
  color: #607d8b;
  font-size: 0.8125rem;
  font-weight: 300;
  vertical-align: middle;
}
.pie-lined .recharts-cartesian-axis-tick-value {
  color: #607d8b;
  font-size: 0.8125rem;
  margin-top: 8px;
  font-weight: 300;
}
</style><style data-jss="">
.jss2388 {
  margin-top: 16px;
}
</style><style data-jss="">
.bar-chart .recharts-legend-item-text {
  color: #607d8b;
  font-size: 0.8125rem;
  font-weight: 300;
  vertical-align: middle;
}
.bar-chart .recharts-cartesian-axis-tick-value {
  color: #607d8b;
  font-size: 0.875rem;
  margin-top: 8px;
}
</style><style data-jss="">
.jss2387 {
  margin-top: 16px;
}
</style><style data-jss="">
.line-chart .recharts-legend-item-text {
  color: #607d8b;
  font-size: 0.8125rem;
  font-weight: 300;
  vertical-align: middle;
}
.line-chart .recharts-cartesian-axis-tick-value {
  color: #607d8b;
  font-size: 0.875rem;
  margin-top: 8px;
}
</style><style data-jss="">
.jss2386 {
  margin-top: 16px;
}
</style><style data-jss="">
.jss661 {
  padding-top: 16px;
  padding-bottom: 16px;
}
.jss662 {
  display: flex;
  justify-content: space-between;
}
.jss664 {
  display: block;
}
.jss665 {
  margin-top: 40px;
}
</style><style data-jss="">
.jss499 {
  display: flex;
  padding: 16px;
}
.jss500 {
  width: calc(100% - 96px);
  display: flex;
  padding-left: 16px;
  flex-direction: column;
  justify-content: space-between;
}
.jss501 {
  width: 96px;
  height: 96px;
  background: #90a4ae;
}
.jss502 {
  color: #fff;
}
@media (min-width:576px) {
  .jss503 {
    max-width: 400px;
  }
}
</style><style data-jss="">
.jss491 {
  width: 192px;
  display: flex;
  flex-wrap: wrap;
}
@media (min-width:576px) {
  .jss491 {
    width: 288px;
  }
}
.jss492 {
  background: #fff;
  padding-top: 16px;
  padding-left: 16px;
  padding-right: 16px;
}
.jss493 {
  width: 96px;
  border: 1px solid transparent;
  cursor: pointer;
  display: flex;
  padding: 8px;
  background: transparent;
  align-items: center;
  margin-bottom: 16px;
  flex-direction: column;
  justify-content: space-between;
  text-decoration: none;
}
.jss493:hover {
  border-color: rgba(69, 90, 100, 0.12);
  text-decoration: none;
}
.jss493:disabled {
  cursor: not-allowed;
  opacity: 0.55;
  border-color: transparent;
}
.jss494 {
  width: 36px;
  height: 36px;
}
.jss495 {
  font-size: 0.8125rem;
}
</style><style data-jss="">
.jss452 {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
@media (min-width:768px) {
  .jss452 {
    margin-left: 16px;
    margin-right: 8px;
    justify-content: space-between;
  }
}
.jss453 {
  height: 24px;
}
@media (min-width:576px) {
  .jss453 {
    height: 28px;
  }
}
@media (min-width:768px) {
  .jss453 {
    height: 32px;
  }
}
.jss454 {
  margin-left: 4px;
}
.jss455 {
  display: flex;
  align-items: center;
}
@media (max-width:767.95px) {
  .jss455 {
    display: none;
  }
}
</style><style data-jss="" data-meta="Wrapper">
.jss367 {
  color: #fff;
  margin: 0 auto;
  display: flex;
  user-select: none;
}
.jss367:hover {
  color: #fff;
  text-decoration: none;
}
.jss368 {
  margin-left: 8px;
}
.jss369 {
  font-size: 1.25rem;
  font-weight: 400;
  line-height: 1;
  letter-spacing: 1px;
}
.jss370 {
  font-size: 0.875rem;
  font-weight: 300;
  line-height: 1;
  letter-spacing: 1px;
}
</style><style data-jss="">
.jss363 {
  flex: 1;
  display: flex;
}
.jss364 {
  min-height: 56px;
}
@media (min-width:0px) and (orientation: landscape) {
  .jss364 {
    min-height: 48px;
  }
}
@media (min-width:576px) {
  .jss364 {
    min-height: 64px;
  }
}
.jss365 {
  flex: 1;
}
.jss366 {
  flex: 1;
  display: flex;
  min-height: 100vh;
  flex-direction: column;
}
</style><style id="detectElementResize" type="text/css">@keyframes resizeanim { from { opacity: 0; } to { opacity: 0; } } .resize-triggers { animation: 1ms resizeanim; visibility: hidden; opacity: 0; } .resize-triggers, .resize-triggers > div, .contract-trigger:before { content: " "; display: block; position: absolute; top: 0; left: 0; height: 100%; width: 100%; overflow: hidden; z-index: -1; } .resize-triggers > div { background: #eee; overflow: auto; } .contract-trigger:before { width: 200%; height: 200%; }</style></head><body class="drawer-md-open" style=""><div id="root" class="root"><div class="jss363"><header class="jss383 jss385 jss375 jss376 jss381 mui-fixed jss371 jss372" id="xdrawer-app-bar" style="padding-right: 0px;"><div class="jss417"><div class="jss425 jss427 jss373"><button tabindex="0" class="jss435 jss429 jss374" type="button" aria-label="open drawer"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span><span class="jss445"></span></button><div class="jss452"><div class="jss455"><button tabindex="0" class="jss435 jss429" type="button" aria-label="MENU"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span></button><span class="jss466 jss476 jss464 jss454">MENU</span></div><div><button tabindex="0" class="jss435 jss429" type="button" aria-haspopup="true" aria-label="Apps"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss445"></span></button><button tabindex="0" class="jss435 jss429" type="button" aria-haspopup="true" aria-label="Minha Conta"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss445"></span></button></div></div></div></div><div class="jss415"><div class="jss425 jss427"><div class="jss452"><div class="jss455"><button tabindex="0" class="jss435 jss429" type="button" aria-label="MENU"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg></span></button><span class="jss466 jss476 jss464 jss454">MENU</span></div><div><button tabindex="0" class="jss435 jss429" type="button" aria-haspopup="true" aria-label="Apps"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss445"></span></button><button tabindex="0" class="jss435 jss429" type="button" aria-haspopup="true" aria-label="Minha Conta"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg></span><span class="jss445"></span></button></div></div></div></div></header><div class="jss415"><div class="jss504"></div><div class="jss511"><div class="jss383 jss385 jss512 jss504 jss513 jss517"><header class="jss507"><a class="jss367" href="/"><img src="/static/media/vendas-logo-outline.7bf3fae0.svg" width="32" height="32" alt="Conexão Vendas"><div class="jss368"><p class="jss466 jss475 jss485 jss370">conexão</p><p class="jss466 jss475 jss485 jss369">Vendas</p></div></a></header><div class="jss505"><ul class="jss537 jss538 jss522"><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Venda</span></div><svg class="jss438 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><defs><path id="a" d="M0 0h24v24H0V0z"></path></defs><path d="M14 10H2v2h12v-2zm0-4H2v2h12V6zM2 16h8v-2H2v2zm19.5-4.5L23 13l-6.99 7-4.51-4.5L13 14l3.01 3 5.49-5.5z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Viabilidade</span></div><svg class="jss438 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.11,16.42A6.9,6.9,0,1,1,7.58,8.89c0-.23.3-.41.3-.64s-.34-.45-.3-.67a8.22,8.22,0,1,0,8.88,8.84c-.22,0-.45-.3-.67-.3S15.34,16.46,15.11,16.42Z"></path><path d="M24,8.25A8.24,8.24,0,0,0,7.54,7.58c.22,0,.45.3.67.3s.41-.34.64-.3a6.92,6.92,0,0,1,13.8.67,6.91,6.91,0,0,1-6.22,6.86c0,.23-.3.41-.3.64s.33.45.3.67A8.21,8.21,0,0,0,24,8.25Z"></path><path d="M16.42,15.11A8.19,8.19,0,0,0,8.89,7.58c-.23,0-.45,0-.68,0a3.77,3.77,0,0,0-.67,0c0,.22,0,.45,0,.67a3.71,3.71,0,0,0,0,.67,8.26,8.26,0,0,0,7.57,7.5c.23,0,.45,0,.68,0a3.77,3.77,0,0,0,.67,0c0-.22,0-.45,0-.67S16.46,15.34,16.42,15.11ZM8.89,8.89a6.94,6.94,0,0,1,6.22,6.22A6.94,6.94,0,0,1,8.89,8.89Z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Simulador</span></div><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20.2 5.9l.8-.8C19.6 3.7 17.8 3 16 3s-3.6.7-5 2.1l.8.8C13 4.8 14.5 4.2 16 4.2s3 .6 4.2 1.7zm-.9.8c-.9-.9-2.1-1.4-3.3-1.4s-2.4.5-3.3 1.4l.8.8c.7-.7 1.6-1 2.5-1 .9 0 1.8.3 2.5 1l.8-.8zM19 13h-2V9h-2v4H5c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2zM8 18H6v-2h2v2zm3.5 0h-2v-2h2v2zm3.5 0h-2v-2h2v2z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Teste de Internet</span></div><span class="jss445"></span></div></ul></div></div></div></div><div class="jss417"></div><div id="inner" class="jss366" style="width: calc(100% - 210px);"><main class="jss365"><div class="jss364"></div><section><div style="height: 40px;"></div><div class="jss593 jss595"><div class="jss594"><div class="jss596"><div class="jss598"><svg class="jss438 jss601" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"></path><path fill="none" d="M0 0h24v24H0z"></path><path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"></path></svg><p class="jss466 jss475 jss602">09/10/18 14:06:40</p></div><div class="jss600"><svg class="jss438 jss601" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><p class="jss466 jss475 jss602">Pamela Aparecida Gomes | Vendedor* Agente Autorizado</p></div><div class="jss599"><svg class="jss438 jss601" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"></path></svg><p class="jss466 jss475 jss602">paaparecidagomes@gmail.com</p></div></div><div class="jss597"><p class="jss466 jss475 jss602 jss605 jss603" title="EDICLEIA MOTTA PEREIRA"><span>Ag. Autorizado:</span> 24.192.830/0001-26</p></div></div></div><header class="jss628 jss629"><div><h2 class="jss466 jss472 jss486 jss630 jss482 jss631">Dashboard</h2><h3 class="jss466 jss473 jss632 jss486 jss482">INICIAL</h3></div></header><div class="container"><div class="row"><div class="col-sm-12"><div class="jss383 jss634 jss388 jss384 jss633"><div class="jss2375"><div style="position: relative;"><h3 class="jss466 jss473 jss2376">Números da Tabulação</h3></div><div class="jss2381"><button tabindex="0" class="jss435 jss429 jss2380" type="button" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"></path></svg></span><span class="jss445"></span></button><button tabindex="0" class="jss435 jss429 jss2380" type="button" aria-haspopup="true" aria-label="More" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path></svg></span><span class="jss445"></span></button></div></div><div class="row"><div class="col-sm-6 col-lg-6 col-xl-3"><div class="jss2383"><p class="jss466 jss475 jss480 jss2384"><span>1</span></p><img width="40" height="40" src="/static/media/dashboard-vendas-icon.d105e9a0.svg" alt=""><p class="jss466 jss475 jss2385">Vendas</p></div></div><div class="col-sm-6 col-lg-6 col-xl-3"><div class="jss2383"><p class="jss466 jss475 jss480 jss2384"><span>0</span></p><img width="40" height="40" src="/static/media/dashboard-nao-vendas-icon.0214482f.svg" alt=""><p class="jss466 jss475 jss2385">Não Venda</p></div></div><div class="col-sm-6 col-lg-6 col-xl-3"><div class="jss2383"><p class="jss466 jss475 jss480 jss2384"><span>0</span></p><img width="40" height="40" src="/static/media/dashboard-agendamentos-icon.688382ce.svg" alt=""><p class="jss466 jss475 jss2385">Agendamentos</p></div></div><div class="col-sm-6 col-lg-6 col-xl-3"><div class="jss2383"><p class="jss466 jss475 jss480 jss2384"><span>0</span></p><img width="40" height="40" src="/static/media/dashboard-telefonia-icon.22327f6b.svg" alt=""><p class="jss466 jss475 jss2385">Telefonia</p></div></div></div></div></div><div class="col-sm-12 jss2386"><div class="jss383 jss634 jss388 jss384 jss633"><div class="jss2375"><div style="position: relative;"><h3 class="jss466 jss473 jss2376">Relatório da Tabulação</h3></div><div class="jss2381"><button tabindex="0" class="jss435 jss429 jss2380" type="button" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"></path></svg></span><span class="jss445"></span></button></div></div><div class="line-chart"><div class="recharts-responsive-container" style="width: 100%; height: 300px; position: relative;"><div class="recharts-wrapper" style="position: relative; cursor: default; width: 1060px; height: 300px;"><svg class="recharts-surface" width="1060" height="300" viewBox="0 0 1060 300" version="1.1"><clipPath id="recharts328-clip"><rect x="44" y="48" height="214" width="1000"></rect></clipPath><g class="recharts-layer recharts-cartesian-axis recharts-xAxis xAxis"><line class="recharts-cartesian-axis-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="44" y1="262" x2="1044" y2="262"></line><g class="recharts-cartesian-axis-ticks"><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="74" y1="268" x2="74" y2="262"></line><text stroke="none" height="30" width="1000" x="74" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="74" dy="0.71em">02/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="230.66666666666666" y1="268" x2="230.66666666666666" y2="262"></line><text stroke="none" height="30" width="1000" x="230.66666666666666" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="230.66666666666666" dy="0.71em">03/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="387.3333333333333" y1="268" x2="387.3333333333333" y2="262"></line><text stroke="none" height="30" width="1000" x="387.3333333333333" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="387.3333333333333" dy="0.71em">04/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="544" y1="268" x2="544" y2="262"></line><text stroke="none" height="30" width="1000" x="544" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="544" dy="0.71em">05/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="700.6666666666666" y1="268" x2="700.6666666666666" y2="262"></line><text stroke="none" height="30" width="1000" x="700.6666666666666" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="700.6666666666666" dy="0.71em">06/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="857.3333333333333" y1="268" x2="857.3333333333333" y2="262"></line><text stroke="none" height="30" width="1000" x="857.3333333333333" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="857.3333333333333" dy="0.71em">08/10</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="1014" y1="268" x2="1014" y2="262"></line><text stroke="none" height="30" width="1000" x="1014" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="1014" dy="0.71em">09/10</tspan></text></g></g></g><g class="recharts-layer recharts-cartesian-axis recharts-yAxis yAxis"><line class="recharts-cartesian-axis-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="44" y1="48" x2="44" y2="262"></line><g class="recharts-cartesian-axis-ticks"><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="262" x2="44" y2="262"></line><text stroke="none" width="60" height="214" x="36" y="262" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">0</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="208.5" x2="44" y2="208.5"></line><text stroke="none" width="60" height="214" x="36" y="208.5" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">1</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="155" x2="44" y2="155"></line><text stroke="none" width="60" height="214" x="36" y="155" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">2</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="101.5" x2="44" y2="101.5"></line><text stroke="none" width="60" height="214" x="36" y="101.5" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">3</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="48" x2="44" y2="48"></line><text stroke="none" width="60" height="214" x="36" y="48" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">4</tspan></text></g></g></g><g class="recharts-cartesian-grid"><g class="recharts-cartesian-grid-horizontal"><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="262" x2="1044" y2="262"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="208.5" x2="1044" y2="208.5"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="155" x2="1044" y2="155"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="101.5" x2="1044" y2="101.5"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="48" x2="1044" y2="48"></line></g></g><g class="recharts-layer recharts-line"><path stroke-width="5" stroke="#4caf50" fill="none" width="1000" height="214" class="recharts-curve recharts-line-curve" d="M74,262C126.22222222222223,262,178.44444444444443,262,230.66666666666666,262C282.88888888888886,262,335.1111111111111,208.5,387.3333333333333,208.5C439.55555555555554,208.5,491.77777777777777,262,544,262C596.2222222222222,262,648.4444444444445,262,700.6666666666666,262C752.8888888888888,262,805.1111111111111,262,857.3333333333333,262C909.5555555555555,262,961.7777777777777,262,1014,262"></path><g class="recharts-layer recharts-line-dots"><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="74" cy="262"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="230.66666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="387.3333333333333" cy="208.5"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="544" cy="262"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="700.6666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="857.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#4caf50" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="1014" cy="262"></circle></g></g><g class="recharts-layer recharts-line"><path stroke-width="5" stroke="#f44336" fill="none" width="1000" height="214" class="recharts-curve recharts-line-curve" d="M74,262C126.22222222222223,262,178.44444444444443,262,230.66666666666666,262C282.88888888888886,262,335.1111111111111,262,387.3333333333333,262C439.55555555555554,262,491.77777777777777,262,544,262C596.2222222222222,262,648.4444444444445,262,700.6666666666666,262C752.8888888888888,262,805.1111111111111,262,857.3333333333333,262C909.5555555555555,262,961.7777777777777,262,1014,262"></path><g class="recharts-layer recharts-line-dots"><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="74" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="230.66666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="387.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="544" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="700.6666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="857.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#f44336" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="1014" cy="262"></circle></g></g><g class="recharts-layer recharts-line"><path stroke-width="5" stroke="#2196f3" fill="none" width="1000" height="214" class="recharts-curve recharts-line-curve" d="M74,262C126.22222222222223,262,178.44444444444443,262,230.66666666666666,262C282.88888888888886,262,335.1111111111111,262,387.3333333333333,262C439.55555555555554,262,491.77777777777777,262,544,262C596.2222222222222,262,648.4444444444445,262,700.6666666666666,262C752.8888888888888,262,805.1111111111111,262,857.3333333333333,262C909.5555555555555,262,961.7777777777777,262,1014,262"></path><g class="recharts-layer recharts-line-dots"><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="74" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="230.66666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="387.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="544" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="700.6666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="857.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#2196f3" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="1014" cy="262"></circle></g></g><g class="recharts-layer recharts-line"><path stroke-width="5" stroke="#ffc107" fill="none" width="1000" height="214" class="recharts-curve recharts-line-curve" d="M74,262C126.22222222222223,262,178.44444444444443,262,230.66666666666666,262C282.88888888888886,262,335.1111111111111,262,387.3333333333333,262C439.55555555555554,262,491.77777777777777,262,544,262C596.2222222222222,262,648.4444444444445,262,700.6666666666666,262C752.8888888888888,262,805.1111111111111,262,857.3333333333333,262C909.5555555555555,262,961.7777777777777,262,1014,262"></path><g class="recharts-layer recharts-line-dots"><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="74" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="230.66666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="387.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="544" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="700.6666666666666" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="857.3333333333333" cy="262"></circle><circle r="3" stroke-width="5" stroke="#ffc107" fill="#fff" width="1000" height="214" class="recharts-dot recharts-line-dot" cx="1014" cy="262"></circle></g></g></svg><div class="recharts-legend-wrapper" style="position: absolute; width: 1060px; height: auto; right: 16px; top: 8px; color: rgb(96, 125, 139); padding-bottom: 16px;"><ul class="recharts-default-legend" style="padding: 0px; margin: 0px; text-align: right;"><li class="recharts-legend-item legend-item-0" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path fill="#4caf50" class="recharts-symbols" transform="translate(16, 16)" d="M-16,-16h32v32h-32Z"></path></svg><span class="recharts-legend-item-text">Vendas</span></li><li class="recharts-legend-item legend-item-1" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path fill="#f44336" class="recharts-symbols" transform="translate(16, 16)" d="M-16,-16h32v32h-32Z"></path></svg><span class="recharts-legend-item-text">Não Vendas</span></li><li class="recharts-legend-item legend-item-2" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path fill="#2196f3" class="recharts-symbols" transform="translate(16, 16)" d="M-16,-16h32v32h-32Z"></path></svg><span class="recharts-legend-item-text">Agendamentos</span></li><li class="recharts-legend-item legend-item-3" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path fill="#ffc107" class="recharts-symbols" transform="translate(16, 16)" d="M-16,-16h32v32h-32Z"></path></svg><span class="recharts-legend-item-text">Telefonias</span></li></ul></div><div class="recharts-tooltip-wrapper recharts-tooltip-wrapper-right recharts-tooltip-wrapper-bottom" style="pointer-events: none; visibility: hidden; position: absolute; top: 0px; color: rgb(96, 125, 139); font-size: 14px; transform: translate(867.333px, 86px);"><div class="recharts-default-tooltip" style="margin: 0px; padding: 10px; background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); white-space: nowrap;"><p class="recharts-tooltip-label" style="margin: 0px;">08/10</p></div></div></div><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; width: 1070px; height: 310px;"></div></div><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; width: 200%; height: 200%;"></div></div></div></div></div></div></div><div class="col-sm-12 jss2387"><div class="jss383 jss634 jss388 jss384 jss633"><div class="jss2375"><div style="position: relative;"><h3 class="jss466 jss473 jss2376">Relatório de Melhor Hora de Venda</h3></div><div class="jss2381"><button tabindex="0" class="jss435 jss429 jss2380" type="button" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"></path></svg></span><span class="jss445"></span></button></div></div><div class="bar-chart"><div class="recharts-responsive-container" style="width: 100%; height: 300px; position: relative;"><div class="recharts-wrapper" style="position: relative; cursor: default; width: 1060px; height: 300px;"><svg class="recharts-surface" width="1060" height="300" viewBox="0 0 1060 300" version="1.1"><clipPath id="recharts334-clip"><rect x="44" y="48" height="214" width="1000"></rect></clipPath><g class="recharts-layer recharts-cartesian-axis recharts-xAxis xAxis"><line class="recharts-cartesian-axis-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="44" y1="262" x2="1044" y2="262"></line><g class="recharts-cartesian-axis-ticks"><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="107.57142857142857" y1="268" x2="107.57142857142857" y2="262"></line><text stroke="none" height="30" width="1000" x="107.57142857142857" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="107.57142857142857" dy="0.71em">08:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="174.71428571428572" y1="268" x2="174.71428571428572" y2="262"></line><text stroke="none" height="30" width="1000" x="174.71428571428572" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="174.71428571428572" dy="0.71em">09:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="241.85714285714283" y1="268" x2="241.85714285714283" y2="262"></line><text stroke="none" height="30" width="1000" x="241.85714285714283" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="241.85714285714283" dy="0.71em">10:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="309" y1="268" x2="309" y2="262"></line><text stroke="none" height="30" width="1000" x="309" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="309" dy="0.71em">11:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="376.1428571428571" y1="268" x2="376.1428571428571" y2="262"></line><text stroke="none" height="30" width="1000" x="376.1428571428571" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="376.1428571428571" dy="0.71em">12:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="443.2857142857142" y1="268" x2="443.2857142857142" y2="262"></line><text stroke="none" height="30" width="1000" x="443.2857142857142" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="443.2857142857142" dy="0.71em">13:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="510.4285714285714" y1="268" x2="510.4285714285714" y2="262"></line><text stroke="none" height="30" width="1000" x="510.4285714285714" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="510.4285714285714" dy="0.71em">14:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="577.5714285714286" y1="268" x2="577.5714285714286" y2="262"></line><text stroke="none" height="30" width="1000" x="577.5714285714286" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="577.5714285714286" dy="0.71em">15:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="644.7142857142857" y1="268" x2="644.7142857142857" y2="262"></line><text stroke="none" height="30" width="1000" x="644.7142857142857" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="644.7142857142857" dy="0.71em">16:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="711.8571428571428" y1="268" x2="711.8571428571428" y2="262"></line><text stroke="none" height="30" width="1000" x="711.8571428571428" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="711.8571428571428" dy="0.71em">17:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="778.9999999999999" y1="268" x2="778.9999999999999" y2="262"></line><text stroke="none" height="30" width="1000" x="778.9999999999999" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="778.9999999999999" dy="0.71em">18:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="846.1428571428571" y1="268" x2="846.1428571428571" y2="262"></line><text stroke="none" height="30" width="1000" x="846.1428571428571" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="846.1428571428571" dy="0.71em">19:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="913.2857142857142" y1="268" x2="913.2857142857142" y2="262"></line><text stroke="none" height="30" width="1000" x="913.2857142857142" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="913.2857142857142" dy="0.71em">20:00</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" height="30" width="1000" x="44" y="262" fill="none" x1="980.4285714285713" y1="268" x2="980.4285714285713" y2="262"></line><text stroke="none" height="30" width="1000" x="980.4285714285713" y="270" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="middle"><tspan x="980.4285714285713" dy="0.71em">21:00</tspan></text></g></g></g><g class="recharts-layer recharts-cartesian-axis recharts-yAxis yAxis"><line class="recharts-cartesian-axis-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="44" y1="48" x2="44" y2="262"></line><g class="recharts-cartesian-axis-ticks"><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="262" x2="44" y2="262"></line><text stroke="none" width="60" height="214" x="36" y="262" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">0</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="208.5" x2="44" y2="208.5"></line><text stroke="none" width="60" height="214" x="36" y="208.5" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">1</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="155" x2="44" y2="155"></line><text stroke="none" width="60" height="214" x="36" y="155" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">2</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="101.5" x2="44" y2="101.5"></line><text stroke="none" width="60" height="214" x="36" y="101.5" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">3</tspan></text></g><g class="recharts-layer recharts-cartesian-axis-tick"><line class="recharts-cartesian-axis-tick-line" stroke="#607d8b" width="60" height="214" x="-16" y="48" fill="none" x1="38" y1="48" x2="44" y2="48"></line><text stroke="none" width="60" height="214" x="36" y="48" fill="#607d8b" stroke-width="2" class="recharts-text recharts-cartesian-axis-tick-value" text-anchor="end"><tspan x="36" dy="0.355em">4</tspan></text></g></g></g><g class="recharts-cartesian-grid"><g class="recharts-cartesian-grid-horizontal"><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="262" x2="1044" y2="262"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="208.5" x2="1044" y2="208.5"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="155" x2="1044" y2="155"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="101.5" x2="1044" y2="101.5"></line><line stroke="#ccc" fill="none" x="44" y="48" width="1000" height="214" x1="44" y1="48" x2="1044" y2="48"></line></g></g><g class="recharts-layer recharts-bar"><g class="recharts-layer recharts-bar-rectangles"><g class="recharts-layer"><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"><path fill="#4caf50" width="53" height="53.5" x="550.7142857142857" y="208.5" radius="0" class="recharts-rectangle" d="M 550.7142857142857,208.5 h 53 v 53.5 h -53 Z"></path></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g><g class="recharts-layer recharts-bar-rectangle"></g></g></g></g></svg><div class="recharts-legend-wrapper" style="position: absolute; width: 1060px; height: auto; right: 16px; top: 8px; color: rgb(96, 125, 139); padding-bottom: 16px;"><ul class="recharts-default-legend" style="padding: 0px; margin: 0px; text-align: right;"><li class="recharts-legend-item legend-item-0" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path fill="#4caf50" class="recharts-symbols" transform="translate(16, 16)" d="M-16,-16h32v32h-32Z"></path></svg><span class="recharts-legend-item-text">Vendas</span></li></ul></div><div class="recharts-tooltip-wrapper recharts-tooltip-wrapper-right recharts-tooltip-wrapper-bottom" style="pointer-events: none; visibility: hidden; position: absolute; top: 0px; color: rgb(96, 125, 139); font-size: 14px; transform: translate(535.286px, 110px);"><div class="recharts-default-tooltip" style="margin: 0px; padding: 10px; background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); white-space: nowrap;"><p class="recharts-tooltip-label" style="margin: 0px;">14:00</p></div></div></div><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; width: 1070px; height: 310px;"></div></div><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; width: 200%; height: 200%;"></div></div></div></div></div><span class="jss466 jss476 jss480 mr-3">Relatório referente às datas entre 08/09/2018 à 09/10/2018</span></div></div><div class="jss2388 col-sm-6"><div class="jss383 jss634 jss388 jss384 jss633"><div class="jss2375"><div style="position: relative;"><h3 class="jss466 jss473 jss2376">Taxa de Conversão</h3><button tabindex="0" class="jss435 jss429 jss2379 jss2377" type="button" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0V0z"></path><path d="M11 7h2v2h-2zM11 11h2v6h-2z"></path><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"></path></svg></span><span class="jss445"></span></button></div><div class="jss2381"><button tabindex="0" class="jss435 jss429 jss2380" type="button" variant="fab"><span class="jss434"><svg class="jss438" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z"></path></svg></span><span class="jss445"></span></button></div></div><div class="jss2389 pie-lined"><div class="recharts-wrapper" style="position: relative; cursor: default; width: 500px; height: 320px;"><svg class="recharts-surface" width="500" height="320" viewBox="0 0 500 320" version="1.1"><clipPath id="recharts322-clip"><rect x="5" y="5" height="286" width="490"></rect></clipPath><g class="recharts-layer recharts-pie"><g clip-path="url(#recharts-pie-323)"><g class="recharts-layer recharts-pie-sector"><g><text x="235" y="155" text-anchor="middle" fill="#607d8b"><tspan x="235" text-anchor="middle" style="font-size: 12px; font-weight: 500;">1</tspan><tspan x="235" text-anchor="middle" dy="15" style="font-size: 12px;">Contatos Efetivos</tspan></text><path fill="#26c6da" class="recharts-sector" d="M 315,155
    A 80,80,0,
    1,0,
    314.9999999878153,155.00139626340152
  L 294.99999999086145,155.00104719755115
            A 60,60,0,
            1,1,
            295,155 Z"></path><path fill="#26c6da" class="recharts-sector" d="M 325,155
    A 90,90,0,
    1,0,
    324.9999999862922,155.00157079632672
  L 320.99999998690146,155.00150098315663
            A 86,86,0,
            1,1,
            321,155 Z"></path><path d="M145,155L125,155L103,155" stroke="#26c6da" fill="none"></path><circle cx="103" cy="155" r="2" fill="#26c6da" stroke="none"></circle><text x="91" y="155" text-anchor="end" fill="#607d8b" style="font-size: 12px;">Convertido</text><text x="91" y="155" dy="18" text-anchor="end" fill="#607d8b" style="font-size: 12px;">100.0% | 1</text></g></g><g class="recharts-layer recharts-pie-sector"></g></g></g></svg><div class="recharts-legend-wrapper" style="position: absolute; width: 490px; height: auto; left: 5px; bottom: 5px;"><ul class="recharts-default-legend" style="padding: 0px; margin: 0px; text-align: center;"><li class="recharts-legend-item legend-item-0" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path stroke="none" fill="#26c6da" d="M0,4h32v24h-32z" class="recharts-legend-icon"></path></svg><span class="recharts-legend-item-text">Convertido</span></li><li class="recharts-legend-item legend-item-1" style="display: inline-block; margin-right: 10px;"><svg class="recharts-surface" width="14" height="14" viewBox="0 0 32 32" version="1.1" style="display: inline-block; vertical-align: middle; margin-right: 4px;"><path stroke="none" fill="#78909c" d="M0,4h32v24h-32z" class="recharts-legend-icon"></path></svg><span class="recharts-legend-item-text">Não Convertido</span></li></ul></div></div></div><div><div class="jss2390"><p class="jss466 jss456 jss475 jss2391">Vendas:<span class="jss466 jss456 jss474 jss2392"> 1</span></p><p class="jss466 jss456 jss475 jss2391">Não Venda:<span class="jss466 jss456 jss474 jss2392"> 0</span></p><p class="jss466 jss456 jss475 jss2391">Agendamentos:<span class="jss466 jss456 jss474 jss2392"> 0</span></p></div><span class="jss466 jss476 jss479">Relatório referente às datas entre 08/09/2018 à 09/10/2018</span></div></div></div></div></div></section></main><hr class="jss666 jss665"><footer class="jss661"><div class="container"><div class="row"><div class="col"><div class="jss662"><div class="d-flex align-items-center"><div class="jss663"><p class="jss466 jss475">Copyright ® 2018. v1.9.5</p><p class="jss466 jss475">Todos os direitos reservados.</p></div></div><img class="jss664" src="/static/media/logo-net-claro-embratel.dc3bdfa6.png" width="143" height="44" alt=""></div></div></div></div></footer></div></div></div><script type="text/javascript" src="main.7fc3d6ac.js"></script><span id="recharts_measurement_span" style="position: absolute; top: -20000px; left: 0px; padding: 0px; margin: 0px; border: none; white-space: pre;">08:00</span><div class="jss497 jss521 jss498"><div class="jss670" aria-hidden="true" style="opacity: 0; will-change: opacity;"></div><div class="jss383 jss401 jss512 jss504 jss513" direction="right" role="document" tabindex="-1" style="transform: translateX(-234px);"><header class="jss507"><a class="jss367" href="/"><img src="/static/media/vendas-logo-outline.7bf3fae0.svg" width="32" height="32" alt="Conexão Vendas"><div class="jss368"><p class="jss466 jss475 jss485 jss370">conexão</p><p class="jss466 jss475 jss485 jss369">Vendas</p></div></a></header><div class="jss505"><ul class="jss537 jss538 jss522"><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Venda</span></div><svg class="jss438 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><defs><path id="a" d="M0 0h24v24H0V0z"></path></defs><path d="M14 10H2v2h12v-2zm0-4H2v2h12V6zM2 16h8v-2H2v2zm19.5-4.5L23 13l-6.99 7-4.51-4.5L13 14l3.01 3 5.49-5.5z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Viabilidade</span></div><svg class="jss438 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M15.11,16.42A6.9,6.9,0,1,1,7.58,8.89c0-.23.3-.41.3-.64s-.34-.45-.3-.67a8.22,8.22,0,1,0,8.88,8.84c-.22,0-.45-.3-.67-.3S15.34,16.46,15.11,16.42Z"></path><path d="M24,8.25A8.24,8.24,0,0,0,7.54,7.58c.22,0,.45.3.67.3s.41-.34.64-.3a6.92,6.92,0,0,1,13.8.67,6.91,6.91,0,0,1-6.22,6.86c0,.23-.3.41-.3.64s.33.45.3.67A8.21,8.21,0,0,0,24,8.25Z"></path><path d="M16.42,15.11A8.19,8.19,0,0,0,8.89,7.58c-.23,0-.45,0-.68,0a3.77,3.77,0,0,0-.67,0c0,.22,0,.45,0,.67a3.71,3.71,0,0,0,0,.67,8.26,8.26,0,0,0,7.57,7.5c.23,0,.45,0,.68,0a3.77,3.77,0,0,0,.67,0c0-.22,0-.45,0-.67S16.46,15.34,16.42,15.11ZM8.89,8.89a6.94,6.94,0,0,1,6.22,6.22A6.94,6.94,0,0,1,8.89,8.89Z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Simulador</span></div><span class="jss445"></span></div><div tabindex="0" class="jss435 jss571 jss569 jss574 jss578 jss568 jss579" role="button"><svg class="jss438 jss582 jss558 jss558" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path fill="none" d="M0 0h24v24H0z"></path><path d="M20.2 5.9l.8-.8C19.6 3.7 17.8 3 16 3s-3.6.7-5 2.1l.8.8C13 4.8 14.5 4.2 16 4.2s3 .6 4.2 1.7zm-.9.8c-.9-.9-2.1-1.4-3.3-1.4s-2.4.5-3.3 1.4l.8.8c.7-.7 1.6-1 2.5-1 .9 0 1.8.3 2.5 1l.8-.8zM19 13h-2V9h-2v4H5c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2zM8 18H6v-2h2v2zm3.5 0h-2v-2h2v2zm3.5 0h-2v-2h2v2z"></path></svg><div class="jss583 jss564 jss584"><span class="jss466 jss473 jss586 jss560 jss561">Teste de Internet</span></div><span class="jss445"></span></div></ul></div></div></div>

            </body>
            </html>