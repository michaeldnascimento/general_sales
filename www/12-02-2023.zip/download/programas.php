'<?php
session_start();

//login_verifica pra verificar o login
include_once "../login/verifica.php";
include_once "../login/visualizarlista.php";



?>

<!--***************INICIO DO CODIGO HTML- INICIO DA PAGINA**************************** -->
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="../css/imagens/16x16.png">
        <title>General Sales</title>


        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../css/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/bootstrap/css/css-geral.css">




    </head>
    <body>

<!--**********************NAVBAR - BARRA DE NAVEGAÇÃO DO SITE******************************** -->

<a href="../download/MicroSIP-3.15.7.exe" download="Nome-da-imagem">MicroSIP-3.15.7</a>




</body>


        <!-- jQuery -->
        <script src="../js/jquery-2.2.3.min.js"></script>
        <script src="../js/scripts-geral.js"></script>
        <script src="../css/bootstrap/js/bootstrap.min.js"></script>



</html>